/// <reference types="react" />
import * as React from 'react';
export default class Maintenance extends React.Component<{
    changeScreen;
}> {
    state: {
        currentPage: string;
    };
    render(): React.ReactElement<{
        changeScreen;
    }>;
}
