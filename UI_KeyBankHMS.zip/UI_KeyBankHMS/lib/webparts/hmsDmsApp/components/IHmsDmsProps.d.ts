export interface IHmsDmsAppProps {
    description: string;
}
