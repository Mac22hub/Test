/// <reference types="react" />
import * as React from 'react';
export default class SearchResults extends React.Component<{
    changeScreen;
    changeScreenNew;
}> {
    state: {
        tableDetails: any[];
    };
    fetchData: () => Promise<void>;
    componentDidMount(): void;
    render(): React.ReactElement<{
        changeScreen;
        changeScreenNew;
    }>;
}
