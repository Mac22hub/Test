/// <reference types="react" />
import * as React from 'react';
export default class FileUpload extends React.Component<{}> {
    state: {
        selectedFile: any;
    };
    onFileChange: (event: any) => void;
    onFileUpload: () => void;
    fileData: () => JSX.Element;
    render(): JSX.Element;
}
