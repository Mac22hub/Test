/// <reference types="react" />
import * as React from 'react';
export default class Search extends React.Component<{
    changeScreenHome;
}> {
    state: {
        tableDetails: any[];
        ssn: string;
        employeeId: string;
        racfId: string;
        firstName: string;
        lastName: string;
        isClicked: boolean;
    };
    fetchData: () => Promise<void>;
    refreshform: () => void;
    changeScreen: () => void;
    changeScreenNew: () => void;
    render(): React.ReactElement<{
        changeScreeHome;
    }>;
}
