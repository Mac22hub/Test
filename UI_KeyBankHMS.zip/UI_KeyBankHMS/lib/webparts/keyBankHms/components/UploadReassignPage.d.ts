/// <reference types="react" />
import * as React from 'react';
export default class uploadReassignPage extends React.Component<{}> {
    state: {
        tableDetails: any[];
        documentTableDetails: any[];
        SelectedFile: any;
        isFilePicked: boolean;
        currentPage: string;
    };
    changeHandler: (event: any) => void;
    handleSubmission: () => void;
    fetchData: () => Promise<void>;
    fetchDocumentData: () => Promise<void>;
    componentDidMount(): void;
    render(): React.ReactElement<{}>;
}
