/// <reference types="react" />
import * as React from 'react';
export default class UserLandingPage extends React.Component<{
    name;
}> {
    state: {
        isclicked: boolean;
    };
    render(): React.ReactElement<{
        name;
    }>;
}
