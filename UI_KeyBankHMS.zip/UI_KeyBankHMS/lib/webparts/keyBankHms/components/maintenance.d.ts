/// <reference types="react" />
import * as React from 'react';
export default class Maintenance extends React.Component<{
    changeScreen;
}> {
    state: {
        page: string;
        tableDetails: any[];
        documentTableDetails: any[];
    };
    fetchData: () => Promise<void>;
    componentDidMount(): void;
    render(): React.ReactElement<{
        changeScreen;
    }>;
}
