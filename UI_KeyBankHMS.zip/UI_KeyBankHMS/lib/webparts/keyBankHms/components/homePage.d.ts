/// <reference types="react" />
import * as React from 'react';
import { IKeyBankHmsProps } from './IKeyBankHmsProps';
export default class HomePage extends React.Component<IKeyBankHmsProps, {}> {
    state: {
        page: string;
    };
    render(): React.ReactElement<IKeyBankHmsProps>;
}
