/// <reference types="react" />
import * as React from 'react';
export default class AdminLandingPage extends React.Component<{
    name;
}> {
    state: {
        detailpage: string;
    };
    changeScreen: () => void;
    render(): React.ReactElement<{
        name;
    }>;
}
