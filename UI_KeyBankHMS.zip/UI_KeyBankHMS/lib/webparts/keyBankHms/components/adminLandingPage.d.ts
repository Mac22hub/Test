/// <reference types="react" />
import * as React from 'react';
export default class AdminLandingPage extends React.Component<{
    name;
}> {
    state: {
        detailpage: boolean;
    };
    render(): React.ReactElement<{
        name;
    }>;
}
