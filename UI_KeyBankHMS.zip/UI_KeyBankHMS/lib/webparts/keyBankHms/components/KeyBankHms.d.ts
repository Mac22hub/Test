/// <reference types="react" />
import * as React from 'react';
import { IKeyBankHmsProps } from './IKeyBankHmsProps';
export default class KeyBankHms extends React.Component<IKeyBankHmsProps, {}> {
    state: {
        username: string;
        password: string;
        isLogin: boolean;
    };
    handleClick: () => void;
    render(): React.ReactElement<IKeyBankHmsProps>;
}
