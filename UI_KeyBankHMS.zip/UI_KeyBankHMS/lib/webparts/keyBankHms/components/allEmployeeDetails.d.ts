/// <reference types="react" />
import * as React from 'react';
export default class AllEmployeeDetails extends React.Component<{
    changeScreen;
    changeScreenNew;
}> {
    state: {
        tableDetails: any[];
    };
    fetchData: () => Promise<void>;
    componentDidMount(): void;
    render(): React.ReactElement<{
        changeScreen;
        changeScreenNew;
    }>;
}
