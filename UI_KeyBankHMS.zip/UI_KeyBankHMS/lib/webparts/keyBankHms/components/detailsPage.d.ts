/// <reference types="react" />
import * as React from 'react';
export default class DetailsPage extends React.Component<{}> {
    state: {
        page: string;
        tableDetails: any[];
        employeeId: string;
        racfId: string;
        firstName: string;
        lastName: string;
        detailpage: boolean;
    };
    fetchData: () => Promise<void>;
    render(): React.ReactElement<{}>;
}
