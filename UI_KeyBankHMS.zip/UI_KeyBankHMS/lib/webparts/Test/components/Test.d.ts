/// <reference types="react" />
import * as React from 'react';
export default class Test extends React.Component<{}> {
    render(): React.ReactElement<{}>;
}
