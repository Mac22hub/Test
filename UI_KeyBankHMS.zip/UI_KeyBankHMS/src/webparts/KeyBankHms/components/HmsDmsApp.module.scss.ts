/* tslint:disable */
require('./HmsDmsApp.module.css');
const styles = {
  keyBankHms: 'keyBankHms_f855286e',
  container: 'container_f855286e',
  row: 'row_f855286e',
  column: 'column_f855286e',
  'ms-Grid': 'ms-Grid_f855286e',
  title: 'title_f855286e',
  subTitle: 'subTitle_f855286e',
  description: 'description_f855286e',
  button: 'button_f855286e',
  label: 'label_f855286e',
  mainHeader: 'mainHeader_f855286e',
  userBanner: 'userBanner_f855286e',
  userDetails: 'userDetails_f855286e',
  anotherBranchButton: 'anotherBranchButton_f855286e',
  employeeCard: 'employeeCard_f855286e',
  userCards: 'userCards_f855286e',
  searchCard: 'searchCard_f855286e',
  homeIcon: 'homeIcon_f855286e',
  tableCard: 'tableCard_f855286e',
  loginCard: 'loginCard_f855286e',
  displayCard: 'displayCard_f855286e',
  searchButton: 'searchButton_f855286e',
  'custom-file-upload': 'custom-file-upload_f855286e',
  employeeDisplayCard: 'employeeDisplayCard_f855286e',
  maintenanceCard: 'maintenanceCard_f855286e',
};

export default styles;
/* tslint:enable */