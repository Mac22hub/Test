import * as React from 'react';

import styles from './KeyBankHms.module.scss';
import UploadPage from './uploadPage';


export default class uploadReassignPage extends React.Component<{}> {

    state = {

        tableDetails: [],
        documentTableDetails: [],
        SelectedFile: null,
        isFilePicked: false,
        currentPage: "uploadReassignPage"
    }

    changeHandler = (event) => {
        this.setState({ SelectedFile: event.target.files[0], isFilePicked: true })
    };

    handleSubmission = () => {
        const formData = new FormData();

        formData.append('File', this.state.SelectedFile);

        fetch(
            'https://localhost:7210/api/v1/Document/AddDocument',
            {
                method: 'POST',
                body: formData,
            }
        )
            .then((response) => response.json())
            .then((result) => {
                console.log('Success:', result);
            })
            .catch((error) => {
                console.error('Error:', error);
            });
    };
    fetchData = async () => {
        const response = await fetch('https://localhost:7210/api/v1/Employees/GetAllEmployees');
        const data = await response.json();
        const res = await data;
        this.setState({ tableDetails: res["payload"] })

    }

    fetchDocumentData = async () => {
        const response = await fetch('https://localhost:7210/api/v1/Document/GetAllDocuments');
        const data = await response.json();
        const res = await data;
        console.log(res)
        this.setState({ documentTableDetails: res["payload"] })
    }

    componentDidMount(): void {
        this.fetchData()
        this.fetchDocumentData()
    }

    public render(): React.ReactElement<{}> {
        return (
            <div>
                {this.state.currentPage === "uploadReassignPage" &&
                    <div>
                        <div>
                            <div className={styles.mainHeader}>
                                <button className={styles.homeIcon}>home</button>
                                <span>HMS Employee Information</span>
                            </div>
                        </div>

                        {/* style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: "150px" }} */}
                        {this.state.tableDetails.map((data) =>
                            <div style={{ marginTop: "60px", width: '100%' }} >
                                <div >
                                    <div style={{ marginBottom: "40px" }}>
                                        <span style={{ marginLeft: "20px", }}> Employee ID</span>
                                        <span style={{ marginLeft: "10px" }}>{data.employeeID}</span>
                                        <span style={{ marginLeft: "158px", }}>RACF ID</span>
                                        <span style={{ marginLeft: "10px" }}>{data.racfid}</span>
                                        <span style={{ marginLeft: "235px", }}>Records hold</span>
                                        <span style={{ marginLeft: "10px" }}>{ }</span>
                                    </div>
                                    {/* <div>
                                RACF ID
                                <span style={{marginLeft : "10px"}}>{data.racfid}</span>
                                </div>
                                <div>
                                Records hold
                                <span style={{marginLeft : "10px"}}>{}</span>
                            </div> */}
                                </div>
                                <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: "50px" }}>
                                    <div>
                                        Hire Date
                                        <span style={{ marginLeft: "10px" }}>{data.originalHireDate}</span>
                                    </div>
                                    <div>
                                        Termination Date
                                        <span style={{ marginLeft: "10px" }}>{data.terminationDate}</span>
                                    </div>
                                    <div>
                                        Last Accessed By
                                        <span style={{ marginLeft: "10px" }}>{data.modifiedBy}</span>
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* <table>
                        <thead>
                        <tr >
                                <td style={{ width: '100px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold' }}>
                                    First Name
                                    </td >
                                    <td style={{ width: '100px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold' }}>
                                    Middle Name
                                    </td>
                                    <td style={{ width: '100px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold' }}>
                                    Last Name
                                    </td>
                                <td style={{ width: '150px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold' }}>
                                    Employee ID
                                </td>
                                <td style={{ width: '150px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold' }}>
                                    Employee Status ID
                                </td>
                                <td style={{ width: '150px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold' }}>
                                    Original Hire Date
                                </td>
                                <td style={{ width: '200px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold' }}>
                                    Most Recent Hire Date
                                </td>

                            </tr>
                        </thead>
                        <tbody>
                            {this.state.tableDetails.map((data) =>
                                <tr>
                                    <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black" }}>
                                        {data.firstName}
                                    </td>
                                    <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black" }}>
                                    {data.middleName}
                                    </td>
                                    <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black" }}>
                                    {data.lastName}
                                    </td>
                                    <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black" }}>
                                        {data.employeeID}
                                        </td>
                                    <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black" }}>
                                    {data.employeeStatus}
                                    </td>
                                    <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black" }}>
                                        {data.originalHireDate}
                                    </td>
                                    <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black" }}>
                                        {data.mostRecentHireDate}
                                        </td>


                                </tr>
                                )}

                                </tbody>
                                </table>
                            </div> */}
                        <div style={{ marginTop: "70px" }}>
                            {/* <label className={styles['custom-file-upload']}>
                        <input type="file" onClick={this.changeHandler} />
                        Upload
                    </label> */}
                            <button className={styles.searchButton} style={{ borderRadius: "5px", marginLeft: "40px", color: "white" }} onClick={() => this.setState({ currentPage: "uploadPage" })}>Upload</button>
                            <button className={styles.searchButton} style={{ borderRadius: "5px", marginLeft: "30px", color: "white" }}>Reassign</button>
                            <button className={styles.searchButton} style={{ borderRadius: "5px", marginLeft: "30px", color: "white" }}>Trash</button>
                            <button className={styles.searchButton} style={{ borderRadius: "5px", marginLeft: "30px", color: "white" }}>Download</button>
                        </div>
                        <div style={{ marginTop: "30px", width: '100%' }} >

                            <table>
                                <thead>
                                    <tr >
                                        <td style={{ width: '150px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold' }}>
                                            Document Type
                                        </td >
                                        <td style={{ width: '150px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold' }}>
                                            Document Date
                                        </td>
                                        <td style={{ width: '150px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold' }}>
                                            upload date
                                        </td>
                                        <td style={{ width: '150px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold' }}>
                                            comments
                                        </td>
                                    </tr>
                                </thead>
                                <tbody>
                                    {this.state.documentTableDetails.map((data) =>
                                        <tr>
                                            <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black" }}>
                                                {data.name}
                                            </td>
                                            <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black" }}>
                                                {data.documentDate}
                                            </td>
                                            <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black" }}>
                                                {data.modified}
                                            </td>
                                            <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black" }}>
                                                {data.comments}
                                            </td>
                                        </tr>
                                    )}

                                </tbody>
                            </table>
                        </div>
                    </div>}
                    {this.state.currentPage === "uploadPage" &&
                    <UploadPage/>
                        
                    }
            </div >
        );
    }
}
