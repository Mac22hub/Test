declare interface IKeyBankHmsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'KeyBankHmsWebPartStrings' {
  const strings: IKeyBankHmsWebPartStrings;
  export = strings;
}
