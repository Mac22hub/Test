import * as React from 'react';
import DetailsPage from './detailsPage';
import styles from './KeyBankHms.module.scss';


export default class UserLandingPage extends React.Component<{name}> {




    state = {
        page : "userPage"
    }
    changeScreen = () => {
        this.setState({ page: "userPage" })
       
    }


    public render(): React.ReactElement<{name}> {




        return (
            <div>
                {this.state.page === "userPage" &&
                <div>
                <div style = {{ display: "flex"}}  className={styles.mainHeader} >
                    <div>
                    <span>HMS Employee Information</span>
                    </div>
                    <div>
                    <span style={{  paddingLeft: "420px"}}>Welcome, {this.props.name}</span>
                    </div>
                    
                </div>
                <div onClick={() => this.setState({ page: "searchPage" })}>
                    <div style={{marginTop: "30px" , marginLeft: "300px"}} className={styles.employeeCard}>
                        <h3>Search employees</h3>
                        
                    </div>
                </div>
                </div>
                }
                {
                 this.state.page == "searchPage" &&  
                 <DetailsPage changeScreenHome={this.changeScreen}/>
                }
            </div>
        );
    }
}
