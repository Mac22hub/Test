import * as React from 'react';
import DetailsPage from './detailsPage';
import styles from './KeyBankHms.module.scss';


export default class UserLandingPage extends React.Component<{name}> {




    state = {
        isclicked : false
    }


    public render(): React.ReactElement<{name}> {




        return (
            <div>
                {this.state.isclicked === false &&
                <div>
                <div style = {{ display: "flex"}}  className={styles.mainHeader} >
                    <div>
                    <span>HMS Employee Information</span>
                    </div>
                    <div>
                    <span style={{  paddingLeft: "420px"}}>Welcome, {this.props.name}</span>
                    </div>
                    
                </div>
                <div onClick={() => this.setState({ isclicked: true })}>
                    <div style={{marginTop: "30px" , marginLeft: "300px"}} className={styles.employeeCard}>
                        <h3>Search employees</h3>
                        
                    </div>
                </div>
                </div>
                }
                {
                 this.state.isclicked === true &&  
                 <DetailsPage/>
                }
            </div>
        );
    }
}
