import * as React from 'react';
import AllEmployeeDetails from './allEmployeeDetails';
import styles from './KeyBankHms.module.scss';


export default class DetailsPage extends React.Component<{}> {

    state = {
        page: "details",
        tableDetails: [],
        employeeId: "",
        racfId: "",
        firstName: "",
        lastName: "",
        detailpage: false
    }
    fetchData = async () => {
        const response = await fetch('https://localhost:7210/api/v1/Employees/GetEmployeeById?id=' + this.state.employeeId, {
            method: "GET",
            mode: "no-cors",
        }
        )
        const res = response.json()
        console.log(res)
    }

    public render(): React.ReactElement<{}> {

        return (
            <div>
            {this.state.detailpage == false && 
            <div>
                <div>
                    <div className={styles.mainHeader}>
                        <button className={styles.homeIcon}>home</button>
                        <span>HMS Employee Information</span>
                    </div>
                </div>
                <div className={styles.searchCard} style={{ height: "250px" }}>
                    <div>
                        <div style={{ height: "50px" , marginLeft : "100px" }}>
                            <label htmlFor="employeeId">Employee id</label>
                            <input style={{marginLeft : "10px"}} type="text" value={this.state.employeeId} onChange={(event) => this.setState({ employeeId: event.target.value })} />
                        </div>
                        <div style={{ height: "50px" , marginLeft : "100px" }}>
                            <label htmlFor='racfId'>RACF ID</label>
                            <input style={{marginLeft : "10px"}} type='text' value={this.state.racfId} onChange={(event) => this.setState({ racfId: event.target.value })} />
                        </div>
                        <div style={{ height: "50px" , marginLeft : "100px" }}>
                            <label htmlFor='firstName'>First Name </label>
                            <input style={{marginLeft : "10px"}} type='text' value={this.state.firstName} onChange={(event) => this.setState({ firstName: event.target.value })} />
                        </div>
                        <div style={{ height: "50px" , marginLeft : "100px" }}>
                            <label htmlFor='lastName'>Last Name</label>
                            <input style={{marginLeft : "10px"}} type='text' value={this.state.lastName} onChange={(event) => this.setState({ lastName: event.target.value })} />
                        </div>
                        <div>
                            <button onClick={() => this.setState( {detailpage : true})}>search</button>
                        </div>
                    </div>

                </div>

            </div>} 
            {this.state.detailpage && <AllEmployeeDetails/>}
            </div>
        );
       
    }
}
