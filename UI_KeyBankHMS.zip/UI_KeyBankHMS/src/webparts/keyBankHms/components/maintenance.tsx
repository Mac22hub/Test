import * as React from 'react';
import AllEmployeeDetails from './allEmployeeDetails';
import DetailsPage from './detailsPage';
import styles from './KeyBankHms.module.scss';


export default class Maintenance extends React.Component<{changeScreen}> {

    state = {
        page: "details",
        tableDetails: [],
        documentTableDetails: []
    }
    fetchData = async () => {
        const response = await fetch('https://localhost:7210/api/v1/Employees/GetAllEmployees');
        const data = await response.json();
        const res = await data;
        console.log(res)
        this.setState({ tableDetails: res["payload"] })
    }

    componentDidMount(): void {
        this.fetchData()
    }

    public render(): React.ReactElement<{changeScreen}> {
        return (
            <div>
                <div>
                    <div className={styles.mainHeader}>
                        <button className={styles.homeIcon} onClick={this.props.changeScreen}>home</button>
                        <span>HMS Employee Information</span>
                    </div>
                </div>

                <div style={{ marginTop: "30px", width: '100%' }} >

                    <table>
                        <thead>
                            <tr >
                                <td style={{ width: '100px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold' }}>
                                    First Name
                                </td >
                                <td style={{ width: '100px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold' }}>
                                    Middle Name
                                </td>
                                <td style={{ width: '100px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold' }}>
                                    Last Name
                                </td>
                                <td style={{ width: '150px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold' }}>
                                    Employee ID
                                </td>
                                <td style={{ width: '150px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold' }}>
                                    Employee Status ID
                                </td>
                                <td style={{ width: '150px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold' }}>
                                    Original Hire Date
                                </td>
                                <td style={{ width: '200px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold' }}>
                                    Most Recent Hire Date
                                </td>

                            </tr>
                        </thead>
                        <tbody>
                            {this.state.tableDetails.map((data) =>
                                <tr>
                                    <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black" }}>
                                        {data.firstName}
                                    </td>
                                    <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black" }}>
                                        {data.middleName}
                                    </td>
                                    <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black" }}>
                                        {data.lastName}
                                    </td>
                                    <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black" }}>
                                        {data.employeeID}
                                    </td>
                                    <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black" }}>
                                        {data.employeeStatus}
                                    </td>
                                    <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black" }}>
                                        {data.originalHireDate}
                                    </td>
                                    <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black" }}>
                                        {data.mostRecentHireDate}
                                    </td>


                                </tr>
                            )}

                        </tbody>
                    </table>
                </div>
                <div style={{ marginTop: "70px" }}>
                    <button className={styles.searchButton} style={{  borderRadius: "5px", marginLeft: "40px", color: "white" }}>Upload</button>
                    <button className={styles.searchButton} style={{  borderRadius: "5px", marginLeft: "30px", color: "white" }}>Reassign</button>
                    <button className={styles.searchButton} style={{ borderRadius: "5px", marginLeft: "30px", color: "white" }}>Trash</button>
                    <button className={styles.searchButton} style={{ borderRadius: "5px", marginLeft: "30px", color: "white" }}>Download</button>
                </div>
                <div style={{ marginTop: "30px", width: '100%' }} >

                    <table>
                        <thead>
                            <tr >
                                <td style={{ width: '150px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold' }}>
                                    Document Type
                                </td >
                                <td style={{ width: '150px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold' }}>
                                    Document Date
                                </td>
                                <td style={{ width: '150px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold' }}>
                                    upload date
                                </td>
                                <td style={{ width: '150px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold' }}>
                                    comments
                                </td>
                            </tr>
                        </thead>
                        <tbody>
                            {this.state.documentTableDetails.map((data) =>
                                <tr>
                                    <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black" }}>
                                        {data.documentType}
                                    </td>
                                    <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black" }}>
                                        {data.documentDate}
                                    </td>
                                    <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black" }}>
                                        {data.uploadDate}
                                    </td>
                                    <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black" }}>
                                        {data.comments}
                                    </td>
                                </tr>
                            )}

                        </tbody>
                    </table>
                </div>
            </div >
        );
    }
}
