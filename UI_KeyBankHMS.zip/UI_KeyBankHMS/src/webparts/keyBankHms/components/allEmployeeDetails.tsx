import * as React from 'react';
import styles from './KeyBankHms.module.scss';


export default class AllEmployeeDetails extends React.Component<{}> {
    

    state = { page: "details" ,
    tableDetails : [ ]
    }
    fetchData = async() => {
        const response = await fetch('https://localhost:7210/api/v1/Employees/GetAllEmployees');
        const data = await response.json();
        const res = await data;
        console.log(res)
        this.setState({ tableDetails : res["payload"] })
    }

    componentDidMount(): void {
        this.fetchData()
    }

    
    
    
    public render(): React.ReactElement<{}> {

        

        
        
        return (

            <div>
                <div>
                    <div className={styles.mainHeader}>
                        <button className={styles.homeIcon}>home</button>
                        <span>HMS Employee Information</span>
                    </div>
                </div>
                <div style={{ marginTop: "10px", width: '100%'}} >

                    <table>
                        <thead>
                            <tr >
                                <td style={{ width: '100px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold'}}>
                                    Firt Name
                                </td >
                                <td style={{  width: '100px',borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold'}}>
                                    Middle Name
                                </td>
                                <td style={{  width: '100px',borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold'}}>
                                    Last Name
                                </td>
                                <td style={{  width: '150px',borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold'}}>
                                    Employee ID
                                </td>
                                <td style={{  width: '150px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold'}}>
                                Employee Status ID
                                </td>
                                <td style={{  width: '150px',borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold'}}>
                                Original Hire Date
                                </td>
                                <td style={{  width: '200px', borderBottom: "1px solid black", borderTop: "1px solid black", fontWeight: 'bold'}}>
                                Most Recent Hire Date
                                </td>
                               
                            </tr>
                        </thead>
                        <tbody>
                            {this.state.tableDetails.map((data) => 
                            <tr>
                              <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black"}}>
                                   {data.firstName} 
                               </td>
                               <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black"}}>
                               {data.middleName}
                               </td>
                               <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black"}}>
                               {data.lastName}
                               </td>
                               <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black"}}>
                               {data.employeeID}
                               </td>
                               <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black"}}>
                               {data.employeeStatus}
                               </td>
                               <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black"}}>
                               {data.originalHireDate}
                               </td>
                               <td style={{ borderBottom: "1px solid black", borderTop: "1px solid black"}}>
                               {data.mostRecentHireDate}
                               </td>
                              
                              
                            </tr>
                            )}

                        </tbody>
                    </table>
                </div>
            </div>
        );
    }
}
