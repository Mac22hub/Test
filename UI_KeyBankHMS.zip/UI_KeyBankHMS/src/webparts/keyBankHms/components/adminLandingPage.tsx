import * as React from 'react';
import AllEmployeeDetails from './allEmployeeDetails';
import DetailsPage from './detailsPage';
import styles from './KeyBankHms.module.scss';
import Maintenance from './maintenance';


export default class AdminLandingPage extends React.Component<{ name }> {
    state = {

        detailpage: "adminPage"
    }
    changeScreen = () => {
        this.setState({ detailpage: "adminPage" })
       
    }
    public render(): React.ReactElement<{ name }> {
        return (
            <div>
                {this.state.detailpage == "adminPage" &&
                    <div>
                        <div style={{ display: "flex" }} className={styles.mainHeader} >
                            <span>HMS Employee Information</span>
                            <span style={{ paddingLeft: "430px" }}>Welcome, {this.props.name}</span>

                        </div>
                        <div>
                            <div style={{ marginTop: '30px' }} className={styles.displayCard}>
                                <div  onClick={() => this.setState({ detailpage: "search" })} className={styles.employeeCard}>
                                    <h3>Search employees</h3>
                                </div>
                                <div className={styles.employeeCard}>
                                    <h3>Upload Documents</h3>
                                </div>
                                <div className={styles.employeeCard}>
                                    <h3>Assign My Documents</h3>
                                </div>
                            </div>
                            <div style={{ marginTop: '30px' }} className={styles.displayCard}>
                                <div className={styles.employeeCard}>
                                    <h3>Assign all Documents</h3>
                                </div>
                                <div className={styles.employeeCard}>
                                    <h3>Reporting</h3>
                                </div>
                                <div className={styles.employeeCard}  onClick={() => this.setState({ detailpage: "maintenance" })}>
                                    <h3>Maintenance</h3>
                                </div>
                            </div>
                        </div>
                    </div>}
                {this.state.detailpage === "search" && <DetailsPage changeScreenHome={this.changeScreen} />}
                {this.state.detailpage === "maintenance" && <Maintenance changeScreen={this.changeScreen} />}
            </div>
        );
    }
}
