import * as React from 'react';
import AllEmployeeDetails from './allEmployeeDetails';
import DetailsPage from './detailsPage';
import styles from './KeyBankHms.module.scss';


export default class AdminLandingPage extends React.Component<{ name }> {
    state = {
       
        detailpage: false
    }
    public render(): React.ReactElement<{ name }> {
        return (
            <div>
            {this.state.detailpage == false && 
            <div>
                <div  style = {{ display: "flex"}}  className={styles.mainHeader} >
                    <span>HMS Employee Information</span>
                    <span style={{ paddingLeft:"430px" }}>Welcome, {this.props.name}</span>

                </div>
                <div style={{ marginTop: '30px' }} className={styles.displayCard} onClick={() => this.setState({ detailpage: true })}>
                    <div className={styles.employeeCard}>
                        <h3>Search employees</h3>
                    </div>
                    <div className={styles.employeeCard}>
                        <h3>Manage employees</h3>
                    </div>
                </div>
            </div> }
            {this.state.detailpage && <DetailsPage/>}
            </div>
        );
    }
}
