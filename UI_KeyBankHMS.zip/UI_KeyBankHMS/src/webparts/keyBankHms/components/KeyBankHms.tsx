import * as React from 'react';
import styles from './KeyBankHms.module.scss';
import { IKeyBankHmsProps } from './IKeyBankHmsProps';
import { escape } from '@microsoft/sp-lodash-subset';
import DetailsPage from './detailsPage';
import AllEmployeeDetails from './allEmployeeDetails';
import HomePage from './homePage';
import AdminLandingPage from './adminLandingPage';
import UserLandingPage from './userLandingPage';

export default class KeyBankHms extends React.Component<IKeyBankHmsProps, {}> {

  state = {
    username: "",
    password: "",
    isLogin: false
  }

  handleClick = () => {
    if (this.state.username == "" || this.state.password == "")
      alert("username and password should not be empty")
    else
      this.setState({ isLogin: true })


  }


  public render(): React.ReactElement<IKeyBankHmsProps> {


    return (
      <div>
        {this.state.isLogin == false &&
          <div>
            <div className={styles.mainHeader}>
              <span>HMS Employee Information</span>
            </div>
            <div className={styles.loginCard} style={{ width: "230px"}}>
              <form>
                <div style={{ marginTop: "70px", marginLeft: "40px" }}>
                  <label>
                    Username :
                  </label>
                  <input name='username' type='text' onChange={(event) => this.setState({ username: event.target.value })} />
                </div>
                <div style={{ marginTop: "10px", marginLeft: "40px" }}>
                  <label>
                    Password :
                  </label>
                  <input name='password' type='password' onChange={(event) => this.setState({ password: event.target.value })} />
                </div>
                <div style={{marginLeft : "90px", marginBottom :"60px"}}>
                  <button onClick={this.handleClick}>Login</button>
                </div>
              </form>
            </div>
          </div>
        }

        {
          this.state.isLogin === true && this.state.username === "admin" && this.state.password === "admin" &&
          <AdminLandingPage name={this.state.username} />
        }
        {
          this.state.isLogin === true && this.state.username !== "admin" &&
          <UserLandingPage  name={this.state.username}/>
        }



      </div>
    )
  }
}
