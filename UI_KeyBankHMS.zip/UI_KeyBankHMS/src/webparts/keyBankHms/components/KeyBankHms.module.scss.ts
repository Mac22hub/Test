/* tslint:disable */
require('./KeyBankHms.module.css');
const styles = {
  keyBankHms: 'keyBankHms_eaaf09ed',
  container: 'container_eaaf09ed',
  row: 'row_eaaf09ed',
  column: 'column_eaaf09ed',
  'ms-Grid': 'ms-Grid_eaaf09ed',
  title: 'title_eaaf09ed',
  subTitle: 'subTitle_eaaf09ed',
  description: 'description_eaaf09ed',
  button: 'button_eaaf09ed',
  label: 'label_eaaf09ed',
  mainHeader: 'mainHeader_eaaf09ed',
  userBanner: 'userBanner_eaaf09ed',
  userDetails: 'userDetails_eaaf09ed',
  anotherBranchButton: 'anotherBranchButton_eaaf09ed',
  employeeCard: 'employeeCard_eaaf09ed',
  userCards: 'userCards_eaaf09ed',
  searchCard: 'searchCard_eaaf09ed',
  homeIcon: 'homeIcon_eaaf09ed',
  tableCard: 'tableCard_eaaf09ed',
  loginCard: 'loginCard_eaaf09ed',
  displayCard: 'displayCard_eaaf09ed',
  searchButton: 'searchButton_eaaf09ed',
};

export default styles;
/* tslint:enable */