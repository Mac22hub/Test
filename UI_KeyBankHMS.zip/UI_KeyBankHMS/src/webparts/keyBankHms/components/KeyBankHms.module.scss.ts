/* tslint:disable */
require('./KeyBankHms.module.css');
const styles = {
  keyBankHms: 'keyBankHms_b3a17dd9',
  container: 'container_b3a17dd9',
  row: 'row_b3a17dd9',
  column: 'column_b3a17dd9',
  'ms-Grid': 'ms-Grid_b3a17dd9',
  title: 'title_b3a17dd9',
  subTitle: 'subTitle_b3a17dd9',
  description: 'description_b3a17dd9',
  button: 'button_b3a17dd9',
  label: 'label_b3a17dd9',
  mainHeader: 'mainHeader_b3a17dd9',
  userBanner: 'userBanner_b3a17dd9',
  userDetails: 'userDetails_b3a17dd9',
  anotherBranchButton: 'anotherBranchButton_b3a17dd9',
  employeeCard: 'employeeCard_b3a17dd9',
  userCards: 'userCards_b3a17dd9',
  searchCard: 'searchCard_b3a17dd9',
  homeIcon: 'homeIcon_b3a17dd9',
  tableCard: 'tableCard_b3a17dd9',
  loginCard: 'loginCard_b3a17dd9',
  displayCard: 'displayCard_b3a17dd9',
};

export default styles;
/* tslint:enable */