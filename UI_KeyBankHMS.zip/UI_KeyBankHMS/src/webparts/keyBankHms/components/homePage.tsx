import * as React from 'react';
import styles from './KeyBankHms.module.scss';
import { IKeyBankHmsProps } from './IKeyBankHmsProps';
import { escape } from '@microsoft/sp-lodash-subset';
import DetailsPage from './detailsPage';
import AllEmployeeDetails from './allEmployeeDetails';

export default class HomePage extends React.Component<IKeyBankHmsProps, {}> {

  state = { page: "home" }
 

  public render(): React.ReactElement<IKeyBankHmsProps> {
    const username = "John Doe"

    return (
      <div>
        {this.state.page === "home" &&
          <div>
            <div className={styles.mainHeader}>
              <span>HMS Employee Information</span>
            </div>
            <div className={styles.userBanner}>
              <div className={styles.userDetails}>
                <span>Welcome, {username}</span>
                <p>Technology Lead</p>
                <p>OR Road 1234</p>
                <p>New Jersy</p>
                <p>USA</p>
              </div>
            </div>
            <div className={styles.userCards}>

              <div className={styles.employeeCard}>
                <h3>Get all Employee Details</h3>
                <button style={{ borderRadius: "5px"}} onClick={() => this.setState({ page: "allDetails" })}>view</button>
              </div>
              <div className={styles.employeeCard}>
                <h3>Get Employee Details By Id</h3>
                <button style={{ borderRadius: "5px"}} onClick={() => this.setState({ page: "detailsById" })}>view</button>
              </div>
              <div className={styles.employeeCard} >
                <h3>Comments</h3>
                <div style={{paddingTop: '24px'}}>
                <button style={{ borderRadius: "5px"}}>view</button>
                </div>
              </div>
            </div>
          </div>}
          {
            this.state.page === "allDetails" &&
            <AllEmployeeDetails />
          }
          {
            this.state.page === "detailsById" &&
            <DetailsPage/>
          }
      </div>
    );
  }
}
