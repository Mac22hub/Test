﻿using System;
using System.Collections.Generic;

namespace KeyBankHMS.DataModels
{
    public partial class TempHmsEmployee
    {
        public int? IdentifierTypeId { get; set; }
        public string? NameInHr { get; set; }
        public string? FirstName { get; set; }
        public string? MiddleName { get; set; }
        public string? LastName { get; set; }
        public string? EmployeeId { get; set; }
        public string? EmployeeStatus { get; set; }
        public DateTime? OriginalHireDate { get; set; }
        public DateTime? MostRecentHireDate { get; set; }
        public DateTime? TerminationDate { get; set; }
        public string? Ssn { get; set; }
        public string? Racfid { get; set; }
        public string? Gender { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string? JobTitle { get; set; }
        public DateTime? JobTitleAsOf { get; set; }
        public string? JobCode { get; set; }
        public DateTime? CompensationChangeDate { get; set; }
        public string? Company { get; set; }
        public string? CostCenter { get; set; }
        public string? BankNumber { get; set; }
        public string? ManagerRacfid { get; set; }
        public string? Manager { get; set; }
        public string? WorkPhone { get; set; }
        public string? Email { get; set; }
        public string? WorkAddress { get; set; }
        public string? WorkCity { get; set; }
        public string? WorkState { get; set; }
        public string? Mbu { get; set; }
        public string? Ebu { get; set; }
        public string? Sbu { get; set; }
        public string? LegacyCompany { get; set; }
        public string? WorkspaceCategory { get; set; }
        public string? Hrbp { get; set; }
        public DateTime? Created { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? Modified { get; set; }
        public string? ModifiedBy { get; set; }
        public string? OperationType { get; set; }
    }
}
