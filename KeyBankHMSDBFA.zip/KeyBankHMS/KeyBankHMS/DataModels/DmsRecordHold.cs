﻿using System;
using System.Collections.Generic;

namespace KeyBankHMS.DataModels
{
    public partial class DmsRecordHold
    {
        public int Id { get; set; }
        public int? Hmsid { get; set; }
        public int? HoldTypeId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public bool? IsPerpetual { get; set; }
        public DateTime? Created { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? Modified { get; set; }
        public string? ModifiedBy { get; set; }
    }
}
