﻿using System;
using System.Collections.Generic;

namespace KeyBankHMS.DataModels
{
    public partial class HmsIdentifierType
    {
        public int Id { get; set; }
        public string? IdentifierType { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public string? ExpiredBy { get; set; }
        public DateTime? Created { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? Modified { get; set; }
        public string? ModifiedBy { get; set; }
    }
}
