﻿using System;
using System.Collections.Generic;

namespace KeyBankHMS.DataModels
{
    public partial class DmsUserAction
    {
        public int Id { get; set; }
        public string? UserAction { get; set; }
        public string? Created { get; set; }
        public string? CreatedBy { get; set; }
        public string? Modified { get; set; }
        public string? ModifiedBy { get; set; }
    }
}
