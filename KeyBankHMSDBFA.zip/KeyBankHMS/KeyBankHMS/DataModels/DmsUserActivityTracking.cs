﻿using System;
using System.Collections.Generic;

namespace KeyBankHMS.DataModels
{
    public partial class DmsUserActivityTracking
    {
        public int Id { get; set; }
        public string? UserActivity { get; set; }
        public int? UserActionId { get; set; }
        public string? UserId { get; set; }
        public int? Hmsid { get; set; }
        public int? DocumentId { get; set; }
        public DateTime? Created { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? Modified { get; set; }
        public string? ModifiedBy { get; set; }
    }
}
