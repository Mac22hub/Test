﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace KeyBankHMS.DataModels
{
    public partial class DataContext : DbContext
    {
        public DataContext()
        {
        }

        public DataContext(DbContextOptions<DataContext> options)
            : base(options)
        {
        }

        public virtual DbSet<DmsComment> DmsComments { get; set; } = null!;
        public virtual DbSet<DmsDocument> DmsDocuments { get; set; } = null!;
        public virtual DbSet<DmsDocumentType> DmsDocumentTypes { get; set; } = null!;
        public virtual DbSet<DmsRecordHold> DmsRecordHolds { get; set; } = null!;
        public virtual DbSet<DmsRecordHoldType> DmsRecordHoldTypes { get; set; } = null!;
        public virtual DbSet<DmsUserAction> DmsUserActions { get; set; } = null!;
        public virtual DbSet<DmsUserActivityTracking> DmsUserActivityTrackings { get; set; } = null!;
        public virtual DbSet<HmsEmployee> HmsEmployees { get; set; } = null!;
        public virtual DbSet<HmsIdentifierType> HmsIdentifierTypes { get; set; } = null!;
        public virtual DbSet<HmsWdimportLog> HmsWdimportLogs { get; set; } = null!;
        public virtual DbSet<StgHmsEmployee> StgHmsEmployees { get; set; } = null!;
        public virtual DbSet<TempHmsEmployee> TempHmsEmployees { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                

                optionsBuilder.UseSqlServer("name=Default");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DmsComment>(entity =>
            {
                entity.ToTable("DMS_Comments");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Created).HasColumnType("date");

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.DocumentId).HasColumnName("DocumentID");

                entity.Property(e => e.Hmsid).HasColumnName("HMSID");

                entity.Property(e => e.Modified).HasColumnType("date");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);
            });

            modelBuilder.Entity<DmsDocument>(entity =>
            {
                entity.ToTable("DMS_Documents");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Author).HasMaxLength(500);

                entity.Property(e => e.Created).HasColumnType("datetime");

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.DocumentDate).HasColumnType("datetime");

                entity.Property(e => e.DocumentTypeId).HasColumnName("DocumentTypeID");

                entity.Property(e => e.DropOffDate).HasColumnType("datetime");

                entity.Property(e => e.DroppedOffBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Hmsid).HasColumnName("HMSID");

                entity.Property(e => e.Modified).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.Name).HasMaxLength(500);

                entity.Property(e => e.PublishedDate).HasColumnType("datetime");

                entity.Property(e => e.RetainedUntil).HasColumnType("datetime");

                entity.Property(e => e.Spurl).HasColumnName("SPUrl");

                entity.Property(e => e.TrashedBy).HasMaxLength(50);

                entity.Property(e => e.TrashedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<DmsDocumentType>(entity =>
            {
                entity.ToTable("DMS_DocumentTypes");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Category)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ContainsPii).HasColumnName("ContainsPII");

                entity.Property(e => e.Created).HasColumnType("datetime");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ExpiredBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ExpiryDate).HasColumnType("date");

                entity.Property(e => e.Modified).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.RestrictedTo)
                    .HasMaxLength(500)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<DmsRecordHold>(entity =>
            {
                entity.ToTable("DMS_RecordHolds");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Created).HasColumnType("datetime");

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.EndDate).HasColumnType("datetime");

                entity.Property(e => e.Hmsid).HasColumnName("HMSID");

                entity.Property(e => e.HoldTypeId).HasColumnName("HoldTypeID");

                entity.Property(e => e.Modified).HasColumnType("date");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.StartDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<DmsRecordHoldType>(entity =>
            {
                entity.ToTable("DMS_RecordHoldTypes");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Created).HasColumnType("datetime");

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.Modified).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.RecordHoldType).HasMaxLength(50);
            });

            modelBuilder.Entity<DmsUserAction>(entity =>
            {
                entity.ToTable("DMS_UserActions");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Created)
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.Property(e => e.Modified)
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.Property(e => e.ModifiedBy)
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.Property(e => e.UserAction)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<DmsUserActivityTracking>(entity =>
            {
                entity.ToTable("DMS_UserActivityTracking");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Created).HasColumnType("date");

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.DocumentId).HasColumnName("DocumentID");

                entity.Property(e => e.Hmsid).HasColumnName("HMSID");

                entity.Property(e => e.Modified).HasColumnType("date");

                entity.Property(e => e.ModifiedBy).HasMaxLength(50);

                entity.Property(e => e.UserActionId).HasColumnName("UserActionID");

                entity.Property(e => e.UserId)
                    .HasMaxLength(50)
                    .HasColumnName("UserID");
            });

            modelBuilder.Entity<HmsEmployee>(entity =>
            {
                entity.HasKey(e => e.Hmsid);

                entity.ToTable("HMS_Employees");

                entity.Property(e => e.Hmsid).HasColumnName("HMSID");

                entity.Property(e => e.BankNumber).HasMaxLength(10);

                entity.Property(e => e.Company).HasMaxLength(150);

                entity.Property(e => e.CompensationChangeDate).HasColumnType("date");

                entity.Property(e => e.CostCenter).HasMaxLength(10);

                entity.Property(e => e.Created).HasColumnType("date");

                entity.Property(e => e.CreatedBy).HasMaxLength(10);

                entity.Property(e => e.DateOfBirth).HasColumnType("date");

                entity.Property(e => e.Ebu)
                    .HasMaxLength(500)
                    .HasColumnName("EBU");

                entity.Property(e => e.Email).HasMaxLength(500);

                entity.Property(e => e.EmployeeId)
                    .HasMaxLength(10)
                    .HasColumnName("EmployeeID");

                entity.Property(e => e.EmployeeStatus).HasMaxLength(50);

                entity.Property(e => e.FirstName).HasMaxLength(150);

                entity.Property(e => e.Gender).HasMaxLength(50);

                entity.Property(e => e.Hrbp)
                    .HasMaxLength(500)
                    .HasColumnName("HRBP");

                entity.Property(e => e.JobCode).HasMaxLength(10);

                entity.Property(e => e.JobTitle).HasMaxLength(150);

                entity.Property(e => e.JobTitleAsOf).HasColumnType("date");

                entity.Property(e => e.LastName).HasMaxLength(150);

                entity.Property(e => e.LegacyCompany).HasMaxLength(500);

                entity.Property(e => e.Manager).HasMaxLength(500);

                entity.Property(e => e.ManagerRacfid)
                    .HasMaxLength(10)
                    .HasColumnName("ManagerRACFID");

                entity.Property(e => e.Mbu)
                    .HasMaxLength(500)
                    .HasColumnName("MBU");

                entity.Property(e => e.MiddleName).HasMaxLength(150);

                entity.Property(e => e.Modified).HasColumnType("date");

                entity.Property(e => e.ModifiedBy).HasMaxLength(10);

                entity.Property(e => e.MostRecentHireDate).HasColumnType("date");

                entity.Property(e => e.NameInHr)
                    .HasMaxLength(500)
                    .HasColumnName("NameInHR");

                entity.Property(e => e.OriginalHireDate).HasColumnType("date");

                entity.Property(e => e.Racfid)
                    .HasMaxLength(10)
                    .HasColumnName("RACFID");

                entity.Property(e => e.Sbu)
                    .HasMaxLength(500)
                    .HasColumnName("SBU");

                entity.Property(e => e.Ssn)
                    .HasMaxLength(11)
                    .HasColumnName("SSN");

                entity.Property(e => e.TerminationDate).HasColumnType("date");

                entity.Property(e => e.WorkAddress).HasMaxLength(500);

                entity.Property(e => e.WorkCity).HasMaxLength(500);

                entity.Property(e => e.WorkPhone).HasMaxLength(20);

                entity.Property(e => e.WorkState).HasMaxLength(150);

                entity.Property(e => e.WorkspaceCategory)
                    .HasMaxLength(10)
                    .IsFixedLength();
            });

            modelBuilder.Entity<HmsIdentifierType>(entity =>
            {
                entity.ToTable("HMS_IdentifierTypes");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Created).HasColumnType("datetime");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ExpiredBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ExpiryDate).HasColumnType("date");

                entity.Property(e => e.IdentifierType)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Modified).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<HmsWdimportLog>(entity =>
            {
                entity.ToTable("HMS_WDImportLogs");

                entity.Property(e => e.TimeStamp).HasColumnType("datetime");
            });

            modelBuilder.Entity<StgHmsEmployee>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("STG_HMS_Employees");

                entity.Property(e => e.BankNumber).HasMaxLength(10);

                entity.Property(e => e.Company).HasMaxLength(150);

                entity.Property(e => e.CompensationChangeDate).HasColumnType("datetime");

                entity.Property(e => e.CostCenter).HasMaxLength(10);

                entity.Property(e => e.Created).HasColumnType("datetime");

                entity.Property(e => e.CreatedBy).HasMaxLength(10);

                entity.Property(e => e.DateOfBirth).HasColumnType("datetime");

                entity.Property(e => e.Ebu)
                    .HasMaxLength(500)
                    .HasColumnName("EBU");

                entity.Property(e => e.Email).HasMaxLength(500);

                entity.Property(e => e.EmployeeId)
                    .HasMaxLength(10)
                    .HasColumnName("EmployeeID");

                entity.Property(e => e.EmployeeStatus).HasMaxLength(50);

                entity.Property(e => e.FirstName).HasMaxLength(150);

                entity.Property(e => e.Gender).HasMaxLength(50);

                entity.Property(e => e.Hrbp)
                    .HasMaxLength(500)
                    .HasColumnName("HRBP");

                entity.Property(e => e.JobCode).HasMaxLength(10);

                entity.Property(e => e.JobTitle).HasMaxLength(150);

                entity.Property(e => e.JobTitleAsOf).HasColumnType("datetime");

                entity.Property(e => e.LastName).HasMaxLength(150);

                entity.Property(e => e.LegacyCompany).HasMaxLength(500);

                entity.Property(e => e.Manager).HasMaxLength(500);

                entity.Property(e => e.ManagerRacfid)
                    .HasMaxLength(10)
                    .HasColumnName("ManagerRACFID");

                entity.Property(e => e.Mbu)
                    .HasMaxLength(500)
                    .HasColumnName("MBU");

                entity.Property(e => e.MiddleName).HasMaxLength(150);

                entity.Property(e => e.Modified).HasColumnType("datetime");

                entity.Property(e => e.ModifiedBy).HasMaxLength(10);

                entity.Property(e => e.MostRecentHireDate).HasColumnType("datetime");

                entity.Property(e => e.NameInHr)
                    .HasMaxLength(500)
                    .HasColumnName("NameInHR");

                entity.Property(e => e.OriginalHireDate).HasColumnType("datetime");

                entity.Property(e => e.Racfid)
                    .HasMaxLength(10)
                    .HasColumnName("RACFID");

                entity.Property(e => e.Sbu)
                    .HasMaxLength(500)
                    .HasColumnName("SBU");

                entity.Property(e => e.Ssn)
                    .HasMaxLength(11)
                    .HasColumnName("SSN");

                entity.Property(e => e.TerminationDate).HasColumnType("datetime");

                entity.Property(e => e.WorkAddress).HasMaxLength(500);

                entity.Property(e => e.WorkCity).HasMaxLength(500);

                entity.Property(e => e.WorkPhone).HasMaxLength(20);

                entity.Property(e => e.WorkState).HasMaxLength(150);

                entity.Property(e => e.WorkspaceCategory)
                    .HasMaxLength(10)
                    .IsFixedLength();
            });

            modelBuilder.Entity<TempHmsEmployee>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("TEMP_HMS_Employees");

                entity.Property(e => e.BankNumber).HasMaxLength(10);

                entity.Property(e => e.Company).HasMaxLength(150);

                entity.Property(e => e.CompensationChangeDate).HasColumnType("date");

                entity.Property(e => e.CostCenter).HasMaxLength(10);

                entity.Property(e => e.Created).HasColumnType("date");

                entity.Property(e => e.CreatedBy).HasMaxLength(10);

                entity.Property(e => e.DateOfBirth).HasColumnType("date");

                entity.Property(e => e.Ebu)
                    .HasMaxLength(500)
                    .HasColumnName("EBU");

                entity.Property(e => e.Email).HasMaxLength(500);

                entity.Property(e => e.EmployeeId)
                    .HasMaxLength(10)
                    .HasColumnName("EmployeeID");

                entity.Property(e => e.EmployeeStatus).HasMaxLength(50);

                entity.Property(e => e.FirstName).HasMaxLength(150);

                entity.Property(e => e.Gender).HasMaxLength(50);

                entity.Property(e => e.Hrbp)
                    .HasMaxLength(500)
                    .HasColumnName("HRBP");

                entity.Property(e => e.JobCode).HasMaxLength(10);

                entity.Property(e => e.JobTitle).HasMaxLength(150);

                entity.Property(e => e.JobTitleAsOf).HasColumnType("date");

                entity.Property(e => e.LastName).HasMaxLength(150);

                entity.Property(e => e.LegacyCompany).HasMaxLength(500);

                entity.Property(e => e.Manager).HasMaxLength(500);

                entity.Property(e => e.ManagerRacfid)
                    .HasMaxLength(10)
                    .HasColumnName("ManagerRACFID");

                entity.Property(e => e.Mbu)
                    .HasMaxLength(500)
                    .HasColumnName("MBU");

                entity.Property(e => e.MiddleName).HasMaxLength(150);

                entity.Property(e => e.Modified).HasColumnType("date");

                entity.Property(e => e.ModifiedBy).HasMaxLength(10);

                entity.Property(e => e.MostRecentHireDate).HasColumnType("date");

                entity.Property(e => e.NameInHr)
                    .HasMaxLength(500)
                    .HasColumnName("NameInHR");

                entity.Property(e => e.OperationType).HasMaxLength(10);

                entity.Property(e => e.OriginalHireDate).HasColumnType("date");

                entity.Property(e => e.Racfid)
                    .HasMaxLength(10)
                    .HasColumnName("RACFID");

                entity.Property(e => e.Sbu)
                    .HasMaxLength(500)
                    .HasColumnName("SBU");

                entity.Property(e => e.Ssn)
                    .HasMaxLength(11)
                    .HasColumnName("SSN");

                entity.Property(e => e.TerminationDate).HasColumnType("date");

                entity.Property(e => e.WorkAddress).HasMaxLength(500);

                entity.Property(e => e.WorkCity).HasMaxLength(500);

                entity.Property(e => e.WorkPhone).HasMaxLength(20);

                entity.Property(e => e.WorkState).HasMaxLength(150);

                entity.Property(e => e.WorkspaceCategory)
                    .HasMaxLength(10)
                    .IsFixedLength();
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
