﻿using System;
using System.Collections.Generic;

namespace KeyBankHMS.DataModels
{
    public partial class DmsRecordHoldType
    {
        public int Id { get; set; }
        public string? RecordHoldType { get; set; }
        public DateTime? Created { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? Modified { get; set; }
        public string? ModifiedBy { get; set; }
    }
}
