﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using KeyBankHMS.DataModels;

namespace KeyBankHMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        private readonly DataContext _context;

        public EmployeesController(DataContext context)
        {
            _context = context;
        }

        // GET: api/Employees
        [HttpGet]
        public async Task<ActionResult<IEnumerable<HmsEmployee>>> GetHmsEmployees()
        {
          if (_context.HmsEmployees == null)
          {
              return NotFound();
          }
            return await _context.HmsEmployees.ToListAsync();
        }

        // GET: api/Employees/5
        [HttpGet("{id}")]
        public async Task<ActionResult<HmsEmployee>> GetHmsEmployee(int id)
        {
          if (_context.HmsEmployees == null)
          {
              return NotFound();
          }
            var hmsEmployee = await _context.HmsEmployees.FindAsync(id);

            if (hmsEmployee == null)
            {
                return NotFound();
            }

            return hmsEmployee;
        }

        // PUT: api/Employees/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutHmsEmployee(int id, HmsEmployee hmsEmployee)
        {
            if (id != hmsEmployee.Hmsid)
            {
                return BadRequest();
            }

            _context.Entry(hmsEmployee).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!HmsEmployeeExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Employees
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<HmsEmployee>> PostHmsEmployee(HmsEmployee hmsEmployee)
        {
          if (_context.HmsEmployees == null)
          {
              return Problem("Entity set 'DataContext.HmsEmployees'  is null.");
          }
            _context.HmsEmployees.Add(hmsEmployee);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetHmsEmployee", new { id = hmsEmployee.Hmsid }, hmsEmployee);
        }

        // DELETE: api/Employees/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteHmsEmployee(int id)
        {
            if (_context.HmsEmployees == null)
            {
                return NotFound();
            }
            var hmsEmployee = await _context.HmsEmployees.FindAsync(id);
            if (hmsEmployee == null)
            {
                return NotFound();
            }

            _context.HmsEmployees.Remove(hmsEmployee);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool HmsEmployeeExists(int id)
        {
            return (_context.HmsEmployees?.Any(e => e.Hmsid == id)).GetValueOrDefault();
        }
    }
}
