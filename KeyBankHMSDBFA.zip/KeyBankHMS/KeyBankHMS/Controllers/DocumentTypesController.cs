﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using KeyBankHMS.DataModels;

namespace KeyBankHMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DocumentTypesController : ControllerBase
    {
        private readonly DataContext _context;

        public DocumentTypesController(DataContext context)
        {
            _context = context;
        }

        // GET: api/DocumentTypes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<DmsDocumentType>>> GetDmsDocumentTypes()
        {
          if (_context.DmsDocumentTypes == null)
          {
              return NotFound();
          }
            return await _context.DmsDocumentTypes.ToListAsync();
        }

        // GET: api/DocumentTypes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<DmsDocumentType>> GetDmsDocumentType(int id)
        {
          if (_context.DmsDocumentTypes == null)
          {
              return NotFound();
          }
            var dmsDocumentType = await _context.DmsDocumentTypes.FindAsync(id);

            if (dmsDocumentType == null)
            {
                return NotFound();
            }

            return dmsDocumentType;
        }

        // PUT: api/DocumentTypes/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutDmsDocumentType(int id, DmsDocumentType dmsDocumentType)
        {
            if (id != dmsDocumentType.Id)
            {
                return BadRequest();
            }

            _context.Entry(dmsDocumentType).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DmsDocumentTypeExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/DocumentTypes
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<DmsDocumentType>> PostDmsDocumentType(DmsDocumentType dmsDocumentType)
        {
          if (_context.DmsDocumentTypes == null)
          {
              return Problem("Entity set 'DataContext.DmsDocumentTypes'  is null.");
          }
            _context.DmsDocumentTypes.Add(dmsDocumentType);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetDmsDocumentType", new { id = dmsDocumentType.Id }, dmsDocumentType);
        }

        // DELETE: api/DocumentTypes/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDmsDocumentType(int id)
        {
            if (_context.DmsDocumentTypes == null)
            {
                return NotFound();
            }
            var dmsDocumentType = await _context.DmsDocumentTypes.FindAsync(id);
            if (dmsDocumentType == null)
            {
                return NotFound();
            }

            _context.DmsDocumentTypes.Remove(dmsDocumentType);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool DmsDocumentTypeExists(int id)
        {
            return (_context.DmsDocumentTypes?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
