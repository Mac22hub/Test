﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using KeyBankHMS.DataModels;

namespace KeyBankHMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DocumentsController : ControllerBase
    {
        private readonly DataContext _context;

        public DocumentsController(DataContext context)
        {
            _context = context;
        }

        // GET: api/Documents
        [HttpGet]
        public async Task<ActionResult<IEnumerable<DmsDocument>>> GetDmsDocuments()
        {
          if (_context.DmsDocuments == null)
          {
              return NotFound();
          }
            return await _context.DmsDocuments.ToListAsync();
        }

        // GET: api/Documents/5
        [HttpGet("{id}")]
        public async Task<ActionResult<DmsDocument>> GetDmsDocument(int id)
        {
          if (_context.DmsDocuments == null)
          {
              return NotFound();
          }
            var dmsDocument = await _context.DmsDocuments.FindAsync(id);

            if (dmsDocument == null)
            {
                return NotFound();
            }

            return dmsDocument;
        }

        // PUT: api/Documents/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutDmsDocument(int id, DmsDocument dmsDocument)
        {
            if (id != dmsDocument.Id)
            {
                return BadRequest();
            }

            _context.Entry(dmsDocument).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DmsDocumentExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Documents
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<DmsDocument>> PostDmsDocument(DmsDocument dmsDocument)
        {
          if (_context.DmsDocuments == null)
          {
              return Problem("Entity set 'DataContext.DmsDocuments'  is null.");
          }
            _context.DmsDocuments.Add(dmsDocument);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetDmsDocument", new { id = dmsDocument.Id }, dmsDocument);
        }

        // DELETE: api/Documents/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDmsDocument(int id)
        {
            if (_context.DmsDocuments == null)
            {
                return NotFound();
            }
            var dmsDocument = await _context.DmsDocuments.FindAsync(id);
            if (dmsDocument == null)
            {
                return NotFound();
            }

            _context.DmsDocuments.Remove(dmsDocument);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool DmsDocumentExists(int id)
        {
            return (_context.DmsDocuments?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
