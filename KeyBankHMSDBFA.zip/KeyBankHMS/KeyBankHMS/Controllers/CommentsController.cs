﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using KeyBankHMS.DataModels;

namespace KeyBankHMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommentsController : ControllerBase
    {
        private readonly DataContext _context;

        public CommentsController(DataContext context)
        {
            _context = context;
        }

        // GET: api/Comments
        [HttpGet]
        public async Task<ActionResult<IEnumerable<DmsComment>>> GetDmsComments()
        {
          if (_context.DmsComments == null)
          {
              return NotFound();
          }
            return await _context.DmsComments.ToListAsync();
        }

        // GET: api/Comments/5
        [HttpGet("{id}")]
        public async Task<ActionResult<DmsComment>> GetDmsComment(int id)
        {
          if (_context.DmsComments == null)
          {
              return NotFound();
          }
            var dmsComment = await _context.DmsComments.FindAsync(id);

            if (dmsComment == null)
            {
                return NotFound();
            }

            return dmsComment;
        }

        // PUT: api/Comments/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutDmsComment(int id, DmsComment dmsComment)
        {
            if (id != dmsComment.Id)
            {
                return BadRequest();
            }

            _context.Entry(dmsComment).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DmsCommentExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Comments
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<DmsComment>> PostDmsComment(DmsComment dmsComment)
        {
          if (_context.DmsComments == null)
          {
              return Problem("Entity set 'DataContext.DmsComments'  is null.");
          }
            _context.DmsComments.Add(dmsComment);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetDmsComment", new { id = dmsComment.Id }, dmsComment);
        }

        // DELETE: api/Comments/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDmsComment(int id)
        {
            if (_context.DmsComments == null)
            {
                return NotFound();
            }
            var dmsComment = await _context.DmsComments.FindAsync(id);
            if (dmsComment == null)
            {
                return NotFound();
            }

            _context.DmsComments.Remove(dmsComment);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool DmsCommentExists(int id)
        {
            return (_context.DmsComments?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
