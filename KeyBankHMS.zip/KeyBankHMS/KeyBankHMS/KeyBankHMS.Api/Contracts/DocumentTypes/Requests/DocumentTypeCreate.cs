﻿namespace KeyBankHMS.Api.Contracts.DocumentTypes.Requests;

public class DocumentTypeCreate
{
    public Guid ID { get; set; }
    public string Name { get; set; }
    public bool ContainsPII { get; set; }
    public string Category { get; set; }
    public bool IsRestricted { get; set; }
    public string RestrictedTo { get; set; }
    public bool HeldForever { get; set; }
    public DateTime ExpiryDate { get; set; }
    public string ExpiredBy { get; set; }
    public DateTime Created { get; set; }
    public string CreatedBy { get; set; }
    public DateTime Modified { get; set; }
    public string ModifiedBy { get; set; }
}