﻿namespace KeyBankHMS.Api.Contracts.Posts.Requests;

public class EmployeeUpdate
{
    public Guid HMSID { get; private set; }
    public int IdentifierTypeId { get; set; }
    public string NameInHR { get; set; }
    public string FirstName { get; set; }
    public string MiddleName { get; set; }
    public string LastName { get; set; }
    public string EmployeeID { get; set; }
    public string EmployeeStatus { get; set; }
    public DateTime OriginalHireDate { get; set; }
    public DateTime MostRecentHireDate { get; set; }
    public DateTime TerminationDate { get; set; }
    public string SSN { get; set; }
    public string RACFID { get; set; }
    public string Gender { get; set; }
    public DateTime DateOfBirth { get; set; }
    public string JobTitle { get; set; }
    public DateTime JobTitleAsOf { get; set; }
    public string JobCode { get; set; }
    public DateTime CompensationChange { get; set; }
    public string Company { get; set; }
    public string CostCenter { get; set; }
    public string BankNumber { get; set; }
    public string ManagerRACFID { get; set; }
    public string Manager { get; set; }
    public string WorkPhone { get; set; }
    public string Email { get; set; }
    public string WorkAddress { get; set; }
    public string WorkCity { get; set; }
    public string WorkState { get; set; }
    public string MBU { get; set; }
    public string EBU { get; set; }
    public string SBU { get; set; }
    public string LegacyCompany { get; set; }
    public string WorkspaceCategory { get; set; }
    public string HRBP { get; set; }
    public DateTime Created { get; set; }
    public string CreatedBy { get; set; }
    public DateTime Modified { get; set; }
    public string ModifiedBy { get; set; }
}