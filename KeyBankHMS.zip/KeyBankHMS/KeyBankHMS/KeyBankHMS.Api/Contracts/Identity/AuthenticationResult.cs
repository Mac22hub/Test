﻿namespace KeyBankHMS.Api.Contracts.Identity;

public class AuthenticationResult
{
    public string Token { get; set; }
}