﻿namespace KeyBankHMS.Api.Contracts.Documents.Requests;

public class DocumentCreate
{
    public Guid ID { get; set; }
    public string Name { get; set; }
    public Guid HMSID { get; set; }
    public int DocumentTypeID { get; set; }
    public DateTime DropOffDate { get; set; }
    public string DroppedOffBy { get; set; }
    public DateTime DocumentDate { get; set; }
    public string PageCount { get; set; }
    public string Author { get; set; }
    public DateTime PublishedDate { get; set; }
    public DateTime TrashedDate { get; set; }
    public string TrashedBy { get; set; }
    public string SPUrl { get; set; }
    public DateTime RetainedUntil { get; set; }
    public DateTime Created { get; set; }
    public string CreatedBy { get; set; }
    public DateTime Modified { get; set; }
    public string ModifiedBy { get; set; }
}