
var builder = WebApplication.CreateBuilder(args);

builder.RegisterServices(typeof(Program));
var MyAllowSpecificOrigins = "_myAllowSpecificOrigins";
var corsSection = builder.Configuration.GetSection("CorsSettings:corsURL").Value;
builder.Services.AddCors(options =>
{
    options.AddPolicy(MyAllowSpecificOrigins,
                          policy =>
                          {
                              //policy.WithOrigins("https://localhost:4321",
                              //                    "https://localhost:4321/temp/workbench.html")
                              //                    .AllowAnyHeader()
                              //                    .AllowAnyMethod();
                              policy.WithOrigins(corsSection)
                                                 .AllowAnyHeader()
                                                 .AllowAnyMethod();
                          });
});

var app = builder.Build();

app.RegisterPipelineComponents(typeof(Program));



app.UseCors(MyAllowSpecificOrigins);
app.Run();
