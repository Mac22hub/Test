﻿using KeyBankHMS.Api.Contracts.DocumentTypes;

using KeyBankHMS.Api.Contracts.DocumentTypes.Requests;
using KeyBankHMS.Application.DocumentTypes.Commands;

using KeyBankHMS.Application.DocumentTypes.Queries;


namespace KeyBankHMS.Api.Controllers.V1
{

    //[Authorize( AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class DocumentTypeTypeController : BaseController
    {
        [HttpGet]
        [Route(ApiRoutes.DocumentType.GetAllDocumentTypes)]
        public async Task<IActionResult> GetAllDocumentTypeTypes(CancellationToken cancellationToken)
        {
            var result = await _mediator.Send(new GetAllDocumentTypes(), cancellationToken);
            return result.IsError ? HandleErrorResponse(result.Errors) : Ok(result);

        }

        
        [HttpPost]
        [Route(ApiRoutes.DocumentType.AddDocumentType)]
        [ValidateModel]
        public async Task<IActionResult> AddDocumentType([FromBody] DocumentTypeCreate newEmp, CancellationToken cancellationToken)
        {
            var command = new CreateDocumentType()
            {

            ID = newEmp.ID,
            Name = newEmp.Name,
            ContainsPII = newEmp.ContainsPII,
            Category = newEmp.Category,
            IsRestricted = newEmp.IsRestricted,
            RestrictedTo = newEmp.RestrictedTo,
            HeldForever = newEmp.HeldForever,
            ExpiryDate = newEmp.ExpiryDate,
            CreatedBy = newEmp.CreatedBy,
            ExpiredBy = newEmp.ExpiredBy,
            Modified = newEmp.Modified,
            ModifiedBy = newEmp.ModifiedBy
        };

            var result = await _mediator.Send(command, cancellationToken);
            return result.IsError ? HandleErrorResponse(result.Errors) : Ok(result);
        }


        [HttpGet]
        [Route(ApiRoutes.DocumentType.GetDocumentTypeById)]
        [ValidateGuid("id")]
        public async Task<IActionResult> GetDocumentTypeById(string id, CancellationToken cancellationToken)
        {
            var empId = Guid.Parse(id);
            var query = new GetDocumentTypeById() { ID = empId };

            var result = await _mediator.Send(query, cancellationToken);
            return result.IsError ? HandleErrorResponse(result.Errors) : Ok(result);
        }

        [HttpPatch]
        [Route(ApiRoutes.DocumentType.UpdateDocumentTypeById)]
        [ValidateGuid("id")]
        [ValidateModel]
        public async Task<IActionResult> UpdateDocumentTypeById([FromBody] DocumentTypeUpdate newEmp, string id, CancellationToken cancellationToken)
        {
            var command = new UpdateDocumentType()
            {

                ID = newEmp.ID,
                Name = newEmp.Name,
                ContainsPII = newEmp.ContainsPII,
                Category = newEmp.Category,
                IsRestricted = newEmp.IsRestricted,
                RestrictedTo = newEmp.RestrictedTo,
                HeldForever = newEmp.HeldForever,
                ExpiryDate = newEmp.ExpiryDate,
                CreatedBy = newEmp.CreatedBy,
                ExpiredBy = newEmp.ExpiredBy,
                Modified = newEmp.Modified,
                ModifiedBy = newEmp.ModifiedBy

            };
            var result = await _mediator.Send(command, cancellationToken);
            return result.IsError ? HandleErrorResponse(result.Errors) : NoContent();
        }

        [HttpDelete]
        [Route(ApiRoutes.DocumentType.DeleteDocumentType)]
        [ValidateGuid("id")]
        public async Task<IActionResult> DeleteDocumentType(string id, CancellationToken cancellationToken)
        {
            var empId = Guid.Parse(id);
            var command = new DeleteDocumentType() { ID = empId };
            var result = await _mediator.Send(command, cancellationToken);
            return result.IsError ? HandleErrorResponse(result.Errors) : NoContent();
        }

    }
}
