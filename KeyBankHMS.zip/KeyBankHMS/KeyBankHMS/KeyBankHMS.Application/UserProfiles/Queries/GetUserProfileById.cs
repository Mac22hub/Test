﻿using KeyBankHMS.Domain.Aggregates.UserProfileAggregate;
using KeyBankHMS.Application.Models;
using MediatR;

namespace KeyBankHMS.Application.UserProfiles.Queries
{
    public class GetUserProfileById : IRequest<OperationResult<UserProfile>>
    {
        public Guid UserProfileId { get; set; }
    }
}
