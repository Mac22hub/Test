﻿namespace KeyBankHMS.Application.UserProfiles;

public class UserProfilesErrorMessages
{
    public const string UserProfileNotFound = "No UserProfile found with ID {0}";
}