﻿
using KeyBankHMS.Application.Enums;
using KeyBankHMS.Application.Models;
using KeyBankHMS.Application.DocumentTypes.Queries;
using KeyBankHMS.Dal;
using MediatR;
using Microsoft.EntityFrameworkCore;

using KeyBankHMS.Domain.Aggregates.DocumentTypeAggregate;

namespace KeyBankHMS.Application.DocumentTypes.QueryHandlers;

public class GetAllDocumentTypesHandler : IRequestHandler<GetAllDocumentTypes, OperationResult<List<DMS_DocumentTypes>>>
{
    private readonly DataContext _ctx;
    public GetAllDocumentTypesHandler(DataContext ctx)
    {
        _ctx = ctx;
    }
    public async Task<OperationResult<List<DMS_DocumentTypes>>> Handle(GetAllDocumentTypes request, CancellationToken cancellationToken)
    {
        var result = new OperationResult<List<DMS_DocumentTypes>>();
        try
        {
            var posts = await _ctx.DMS_DocumentTypes.ToListAsync();
            result.Payload = posts;
        }
        catch (Exception e)
        {
            result.AddUnknownError(e.Message);
        }

        return result;
    }
}