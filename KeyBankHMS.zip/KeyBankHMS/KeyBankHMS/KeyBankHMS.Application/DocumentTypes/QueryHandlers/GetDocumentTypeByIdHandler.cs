﻿using KeyBankHMS.Application.Enums;
using KeyBankHMS.Application.Models;
using KeyBankHMS.Application.DocumentTypes.Queries;
using KeyBankHMS.Dal;
using MediatR;
using Microsoft.EntityFrameworkCore;
using KeyBankHMS.Application.Comments;
using KeyBankHMS.Domain.Aggregates.DocumentTypeAggregate;

namespace KeyBankHMS.Application.DocumentTypes.QueryHandlers;

public class GetDocumentTypeByIdHandler : IRequestHandler<GetDocumentTypeById, OperationResult<DMS_DocumentTypes>>
{
    private readonly DataContext _ctx;
    public GetDocumentTypeByIdHandler(DataContext ctx)
    {
        _ctx = ctx;
    }
    public async Task<OperationResult<DMS_DocumentTypes>> Handle(GetDocumentTypeById request, CancellationToken cancellationToken)
    {
        var result = new OperationResult<DMS_DocumentTypes>();
        var emp = await _ctx.DMS_DocumentTypes.FirstOrDefaultAsync(p => p.ID == request.ID);

        


        if (emp is null)
        {
            //result.AddError(ErrorCode.NotFound, 
            //    string.Format(CommentErrorMessages.CommentNotFound, request.HMSID));
            return result;
        }

        //result.Payload = emp;
        return result;
    }
}