﻿using KeyBankHMS.Domain.Aggregates.DocumentTypeAggregate;
using KeyBankHMS.Application.Enums;
using KeyBankHMS.Application.Models;
using KeyBankHMS.Application.Posts.Commands;
using KeyBankHMS.Dal;
using MediatR;
using Microsoft.EntityFrameworkCore;
using KeyBankHMS.Application.DocumentTypes.Commands;
using KeyBankHMS.Application.DocumentTypes;

namespace KeyBankHMS.Application.DocumentTypes.CommandHandlers;

public class DeleteDocumentTypeHandler : IRequestHandler<DeleteDocumentType, OperationResult<DMS_DocumentTypes>>
{
    private readonly DataContext _ctx;

    public DeleteDocumentTypeHandler(DataContext ctx)
    {
        _ctx = ctx;
    }
    
    public async Task<OperationResult<DMS_DocumentTypes>> Handle(DeleteDocumentType request, CancellationToken cancellationToken)
    {
        var result = new OperationResult<DMS_DocumentTypes>();
        try
        {
            var emp = await _ctx.DMS_DocumentTypes.FirstOrDefaultAsync(p => p.ID == request.ID, cancellationToken: cancellationToken);
            
            if (emp is null)
            {
                //result.AddError(ErrorCode.NotFound, 
                //    string.Format(CommentErrorMessages.CommentNotFound, request.ID));
                
                return result;
            }

            //if (emp.HMSID != request.UserProfileId)
            //{
            //    result.AddError(ErrorCode.PostDeleteNotPossible, EmployeesErrorMessages.EmployeeDeleteNotPossible);
            //    return result;
            //}

            _ctx.DMS_DocumentTypes.Remove(emp);
            await _ctx.SaveChangesAsync(cancellationToken);

           // result.Payload = emp;
        }
        catch (Exception e)
        {
            result.AddUnknownError(e.Message);
        }

        return result;
    }
}