﻿
using KeyBankHMS.Domain.Exceptions;
using KeyBankHMS.Application.Enums;
using KeyBankHMS.Application.Models;
using KeyBankHMS.Dal;
using MediatR;
using KeyBankHMS.Application.DocumentTypes.Commands;
using KeyBankHMS.Domain.Aggregates.DocumentTypeAggregate;

namespace KeyBankHMS.Application.DocumentTypes.CommandHandlers;

public class CreateDocumentTypeHandler : IRequestHandler<CreateDocumentType, OperationResult<DMS_DocumentTypes>>
{
    private readonly DataContext _ctx;

    public CreateDocumentTypeHandler(DataContext ctx)
    {
        _ctx = ctx;
    }
    
    public async Task<OperationResult<DMS_DocumentTypes>> Handle(CreateDocumentType request, CancellationToken cancellationToken)
    {
        var result = new OperationResult<DMS_DocumentTypes>();
        try
        {
            DMS_DocumentTypes obj = new DMS_DocumentTypes();
            obj.ID = request.ID;
            obj.Name = request.Name;
            obj.ContainsPII = request.ContainsPII;
            obj.Category = request.Category;
            obj.IsRestricted = request.IsRestricted;
            obj.RestrictedTo = request.RestrictedTo;
            obj.HeldForever = request.HeldForever;
            obj.ExpiryDate = request.ExpiryDate;
            obj.CreatedBy = request.CreatedBy;
            obj.ExpiredBy = request.ExpiredBy;
            obj.CreatedBy = request.CreatedBy;
            obj.Modified = request.Modified;
            obj.ModifiedBy = request.ModifiedBy;
            _ctx.DMS_DocumentTypes.Add(obj);
            await _ctx.SaveChangesAsync(cancellationToken);
            result.Payload = obj;
        }
        catch (PostNotValidException e)
        {
            e.ValidationErrors.ForEach(er => result.AddError(ErrorCode.ValidationError, er));
        }

        catch (Exception e)
        {
            result.AddUnknownError(e.Message);
        }
        
        return result;
    }
}