﻿using KeyBankHMS.Domain.Aggregates.DocumentTypeAggregate;
using KeyBankHMS.Application.Models;
using MediatR;

namespace KeyBankHMS.Application.DocumentTypes.Queries;

public class GetDocumentTypeById : IRequest<OperationResult<DMS_DocumentTypes>>
{
    public Guid ID { get; set; }
}