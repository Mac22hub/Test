﻿using KeyBankHMS.Domain.Aggregates.DocumentTypeAggregate;
using KeyBankHMS.Application.Models;
using MediatR;

namespace KeyBankHMS.Application.DocumentTypes.Queries;

public class GetAllDocumentTypes : IRequest<OperationResult<List<DMS_DocumentTypes>>>
{
    
}