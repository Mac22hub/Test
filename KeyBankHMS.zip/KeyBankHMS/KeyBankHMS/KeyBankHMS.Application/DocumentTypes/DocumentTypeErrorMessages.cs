﻿namespace KeyBankHMS.Application.DocumentTypes;

public class DocumentTypeErrorMessages
{
    public const string DocumentTypeNotFound = "No DocumentType found with ID {0}";
    public const string DocumentTypeDeleteNotPossible = "Only the owner of a DocumentType can delete it";

    public const string DocumentTypeUpdateNotPossible =
        "DocumentType update not possible because it's not the DocumentType owner that initiates the update";

    public const string DocumentTypeInteractionNotFound = "Interaction not found";
    public const string InteractionRemovalNotAuthorized = "Cannot remove interaction as you are not its author";
    public const string DocumentTypeDocumentTypeNotFound = "DocumentType not found";
    public const string DocumentTypeRemovalNotAuthorized = "Cannot remove DocumentType from DocumentType as you are not its author";
}