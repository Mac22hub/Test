﻿using KeyBankHMS.Domain.Aggregates.EmployeeAggregate;
using KeyBankHMS.Application.Enums;
using KeyBankHMS.Application.Models;
using KeyBankHMS.Application.Employees.Queries;
using KeyBankHMS.Dal;
using MediatR;
using Microsoft.EntityFrameworkCore;
using KeyBankHMS.Application.Employees;

namespace KeyBankHMS.Application.Employees.QueryHandlers;

public class GetEmployeeBySearchCritriaHandler : IRequestHandler<GetEmployeeBySearchCritria, OperationResult<HMS_Employee>>
{
    private readonly DataContext _ctx;
    public GetEmployeeBySearchCritriaHandler(DataContext ctx)
    {
        _ctx = ctx;
    }
    public async Task<OperationResult<HMS_Employee>> Handle(GetEmployeeBySearchCritria request, CancellationToken cancellationToken)
    {
        var result = new OperationResult<HMS_Employee>();
        var emp = await _ctx.HMS_Employee.FirstOrDefaultAsync(p => p.SSN == request.SSN || p.EmployeeID == request.EmployeeID || p.RACFID == request.RACFID || p.FirstName == request.FirstName || p.LastName == request.LastName);

        


        if (emp is null)
        {
            //result.AddError(ErrorCode.NotFound, 
            //    string.Format(EmployeesErrorMessages.EmployeeNotFound, request.HMSID));
            //return result;
        }

        result.Payload = emp;
        return result;
    }
}