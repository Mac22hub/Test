﻿using KeyBankHMS.Domain.Aggregates.EmployeeAggregate;
using KeyBankHMS.Domain.Exceptions;
using KeyBankHMS.Application.Enums;
using KeyBankHMS.Application.Models;
using KeyBankHMS.Application.Employees.Commands;
using KeyBankHMS.Dal;
using MediatR;

namespace KeyBankHMS.Application.Employees.CommandHandlers;

public class CreateEmployeeHandler : IRequestHandler<CreateEmployee, OperationResult<HMS_Employee>>
{
    private readonly DataContext _ctx;

    public CreateEmployeeHandler(DataContext ctx)
    {
        _ctx = ctx;
    }
    
    public async Task<OperationResult<HMS_Employee>> Handle(CreateEmployee request, CancellationToken cancellationToken)
    {
        var result = new OperationResult<HMS_Employee>();
        try
        {
            HMS_Employee obj = new HMS_Employee();
			obj.IdentifierTypeId = request.IdentifierTypeId;
			obj.NameInHR = request.NameInHR;
			obj.FirstName = request.FirstName;
			obj.MiddleName = request.MiddleName;
			obj.LastName = request.LastName;
			obj.EmployeeID = request.EmployeeID;
			obj.EmployeeStatus = request.EmployeeStatus;
			obj.OriginalHireDate = request.OriginalHireDate;
			obj.MostRecentHireDate = request.MostRecentHireDate;
			obj.TerminationDate = request.TerminationDate;
			obj.SSN = request.SSN;
			obj.RACFID = request.RACFID;
			obj.Gender = request.Gender;
			obj.DateOfBirth = request.DateOfBirth;
			obj.JobTitle = request.JobTitle;
			obj.JobTitleAsOf = request.JobTitleAsOf;
			obj.JobCode = request.JobCode;
			obj.CompensationChange = request.CompensationChange;
			obj.Company = request.Company;
			obj.CostCenter = request.CostCenter;
			obj.BankNumber = request.BankNumber;
			obj.ManagerRACFID = request.ManagerRACFID;
			obj.Manager = request.Manager;
			obj.WorkPhone = request.WorkPhone;
			obj.Email = request.Email;
			obj.WorkAddress = request.WorkAddress;
			obj.WorkCity = request.WorkCity;
			obj.WorkState = request.WorkState;
			obj.MBU = request.MBU;
			obj.EBU = request.EBU;
			obj.SBU = request.SBU;
			obj.LegacyCompany = request.LegacyCompany;
			obj.WorkspaceCategory = request.WorkspaceCategory;
			obj.HRBP = request.HRBP;
			obj.Created = request.Created;
			obj.CreatedBy = request.CreatedBy;
			obj.Modified = request.Modified;
			obj.ModifiedBy = request.ModifiedBy;

			_ctx.HMS_Employee.Add(obj);
            await _ctx.SaveChangesAsync(cancellationToken);
            result.Payload = obj;

            //var post = Employee.CreateEmployee(request.UserProfileId, request.TextContent);
            //_ctx.Posts.Add(post);
            //await _ctx.SaveChangesAsync(cancellationToken);
            //result.Payload = post;
        }
        catch (PostNotValidException e)
        {
            e.ValidationErrors.ForEach(er => result.AddError(ErrorCode.ValidationError, er));
        }

        catch (Exception e)
        {
            result.AddUnknownError(e.Message);
        }
        
        return result;
    }
}