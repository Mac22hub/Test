﻿using KeyBankHMS.Domain.Aggregates.EmployeeAggregate;
using KeyBankHMS.Domain.Exceptions;
using KeyBankHMS.Application.Enums;
using KeyBankHMS.Application.Models;
using KeyBankHMS.Application.Employees.Commands;
using KeyBankHMS.Dal;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace KeyBankHMS.Application.Employees.CommandHandlers;

public class UpdateEmployeeHandler : IRequestHandler<UpdateEmployee, OperationResult<HMS_Employee>>
{
    private readonly DataContext _ctx;

    public UpdateEmployeeHandler(DataContext ctx)
    {
        _ctx = ctx;
    }
    
    public async Task<OperationResult<HMS_Employee>> Handle(UpdateEmployee request, CancellationToken cancellationToken)
    {
        var result = new OperationResult<HMS_Employee>();

        try
        {
            var emp = await _ctx.HMS_Employee.FirstOrDefaultAsync(p => p.HMSID == request.HMSID, cancellationToken: cancellationToken);
            
            if (emp is null)
            {
                result.AddError(ErrorCode.NotFound, 
                    string.Format(EmployeesErrorMessages.EmployeeNotFound, request.HMSID));
                return result;
            }

            //if (emp.HMSID != request.HMSID)
            //{
            //    result.AddError(ErrorCode.PostUpdateNotPossible, EmployeesErrorMessages.EmployeeUpdateNotPossible);
            //    return result;
            //}

            //emp.UpdatePostText(request.NewText);
            emp.IdentifierTypeId = request.IdentifierTypeId;
            emp.NameInHR = request.NameInHR;
            emp.FirstName = request.FirstName;
            emp.MiddleName = request.MiddleName;
            emp.LastName = request.LastName;
            emp.EmployeeID = request.EmployeeID;
            emp.EmployeeStatus = request.EmployeeStatus;
            emp.OriginalHireDate = request.OriginalHireDate;
            emp.MostRecentHireDate = request.MostRecentHireDate;
            emp.TerminationDate = request.TerminationDate;
            emp.SSN = request.SSN;
            emp.RACFID = request.RACFID;
            emp.Gender = request.Gender;
            emp.DateOfBirth = request.DateOfBirth;
            emp.JobTitle = request.JobTitle;
            emp.JobTitleAsOf = request.JobTitleAsOf;
            emp.JobCode = request.JobCode;
            emp.CompensationChange = request.CompensationChange;
            emp.Company = request.Company;
            emp.CostCenter = request.CostCenter;
            emp.BankNumber = request.BankNumber;
            emp.ManagerRACFID = request.ManagerRACFID;
            emp.Manager = request.Manager;
            emp.WorkPhone = request.WorkPhone;
            emp.Email = request.Email;
            emp.WorkAddress = request.WorkAddress;
            emp.WorkCity = request.WorkCity;
            emp.WorkState = request.WorkState;
            emp.MBU = request.MBU;
            emp.EBU = request.EBU;
            emp.SBU = request.SBU;
            emp.LegacyCompany = request.LegacyCompany;
            emp.WorkspaceCategory = request.WorkspaceCategory;
            emp.HRBP = request.HRBP;
            emp.Created = request.Created;
            emp.CreatedBy = request.CreatedBy;
            emp.Modified = request.Modified;
            emp.ModifiedBy = request.ModifiedBy;

            await _ctx.SaveChangesAsync(cancellationToken);

            result.Payload = emp;
        }
        
        catch (PostNotValidException e)
        {
            e.ValidationErrors.ForEach(er => result.AddError(ErrorCode.ValidationError, er));
        }
        catch (Exception e)
        {
            result.AddUnknownError(e.Message);
        }

        return result;
    }
}