﻿using KeyBankHMS.Domain.Aggregates.EmployeeAggregate;
using KeyBankHMS.Application.Models;
using MediatR;


namespace KeyBankHMS.Application.Employees.Queries;

public class GetEmployeeBySearchCritria : IRequest<OperationResult<HMS_Employee>>
{
    
    public string SSN { get; set; }
    public string EmployeeID { get; set; }
    public string RACFID { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    
}