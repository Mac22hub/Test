﻿using KeyBankHMS.Domain.Aggregates.DocumentAggregate;
using KeyBankHMS.Application.Enums;
using KeyBankHMS.Application.Models;
using KeyBankHMS.Application.Posts.Commands;
using KeyBankHMS.Dal;
using MediatR;
using Microsoft.EntityFrameworkCore;
using KeyBankHMS.Application.Documents.Commands;
using KeyBankHMS.Application.Documents;

namespace KeyBankHMS.Application.Documents.CommandHandlers;

public class DeleteDocumentHandler : IRequestHandler<DeleteDocument, OperationResult<DMS_Documents>>
{
    private readonly DataContext _ctx;

    public DeleteDocumentHandler(DataContext ctx)
    {
        _ctx = ctx;
    }
    
    public async Task<OperationResult<DMS_Documents>> Handle(DeleteDocument request, CancellationToken cancellationToken)
    {
        var result = new OperationResult<DMS_Documents>();
        try
        {
            var emp = await _ctx.DMS_Documents.FirstOrDefaultAsync(p => p.ID == request.ID, cancellationToken: cancellationToken);
            
            if (emp is null)
            {
                //result.AddError(ErrorCode.NotFound, 
                //    string.Format(CommentErrorMessages.CommentNotFound, request.ID));
                
                return result;
            }

            //if (emp.HMSID != request.UserProfileId)
            //{
            //    result.AddError(ErrorCode.PostDeleteNotPossible, EmployeesErrorMessages.EmployeeDeleteNotPossible);
            //    return result;
            //}

            _ctx.DMS_Documents.Remove(emp);
            await _ctx.SaveChangesAsync(cancellationToken);

           // result.Payload = emp;
        }
        catch (Exception e)
        {
            result.AddUnknownError(e.Message);
        }

        return result;
    }
}