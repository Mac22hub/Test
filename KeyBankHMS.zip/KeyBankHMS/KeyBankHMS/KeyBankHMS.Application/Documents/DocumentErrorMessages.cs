﻿namespace KeyBankHMS.Application.Documents;

public class DocumentErrorMessages
{
    public const string DocumentNotFound = "No Document found with ID {0}";
    public const string DocumentDeleteNotPossible = "Only the owner of a Document can delete it";

    public const string DocumentUpdateNotPossible =
        "Document update not possible because it's not the Document owner that initiates the update";

    public const string DocumentInteractionNotFound = "Interaction not found";
    public const string InteractionRemovalNotAuthorized = "Cannot remove interaction as you are not its author";
    public const string DocumentDocumentNotFound = "Document not found";
    public const string DocumentRemovalNotAuthorized = "Cannot remove Document from Document as you are not its author";
}