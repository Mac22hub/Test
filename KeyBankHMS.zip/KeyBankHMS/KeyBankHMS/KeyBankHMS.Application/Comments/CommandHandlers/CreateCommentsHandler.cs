﻿using KeyBankHMS.Domain.Aggregates.CommentAggregate;
using KeyBankHMS.Domain.Exceptions;
using KeyBankHMS.Application.Enums;
using KeyBankHMS.Application.Models;
using KeyBankHMS.Dal;
using MediatR;
using KeyBankHMS.Application.Comments.Commands;

namespace KeyBankHMS.Application.Comments.CommandHandlers;

public class CreateDocumentHandler : IRequestHandler<CreateComment, OperationResult<DMS_Comments>>
{
    private readonly DataContext _ctx;

    public CreateDocumentHandler(DataContext ctx)
    {
        _ctx = ctx;
    }
    
    public async Task<OperationResult<DMS_Comments>> Handle(CreateComment request, CancellationToken cancellationToken)
    {
        var result = new OperationResult<DMS_Comments>();
        try
        {
			DMS_Comments obj = new DMS_Comments();
            obj.ID = request.ID;
            obj.CommentText = request.CommentText;
            obj.HMSID = request.HMSID;
            obj.DocumentID = request.DocumentID;
            obj.Created = request.Created;
			obj.CreatedBy = request.CreatedBy;
			obj.Modified = request.Modified;
			obj.ModifiedBy = request.ModifiedBy;
			


            _ctx.DMS_Comments.Add(obj);
            await _ctx.SaveChangesAsync(cancellationToken);
            result.Payload = obj;

            //var post = Employee.CreateEmployee(request.UserProfileId, request.TextContent);
            //_ctx.Posts.Add(post);
            //await _ctx.SaveChangesAsync(cancellationToken);
            //result.Payload = post;
        }
        catch (PostNotValidException e)
        {
            e.ValidationErrors.ForEach(er => result.AddError(ErrorCode.ValidationError, er));
        }

        catch (Exception e)
        {
            result.AddUnknownError(e.Message);
        }
        
        return result;
    }
}