﻿using KeyBankHMS.Domain.Aggregates.CommentAggregate;
using KeyBankHMS.Application.Enums;
using KeyBankHMS.Application.Models;
using KeyBankHMS.Application.Posts.Commands;
using KeyBankHMS.Dal;
using MediatR;
using Microsoft.EntityFrameworkCore;
using KeyBankHMS.Application.Comments.Commands;
using KeyBankHMS.Application.Comments;

namespace KeyBankHMS.Application.Comments.CommandHandlers;

public class DeleteDocumentHandler : IRequestHandler<DeleteComment, OperationResult<DMS_Comments>>
{
    private readonly DataContext _ctx;

    public DeleteDocumentHandler(DataContext ctx)
    {
        _ctx = ctx;
    }
    
    public async Task<OperationResult<DMS_Comments>> Handle(DeleteComment request, CancellationToken cancellationToken)
    {
        var result = new OperationResult<DMS_Comments>();
        try
        {
            var emp = await _ctx.DMS_Comments.FirstOrDefaultAsync(p => p.ID == request.ID, cancellationToken: cancellationToken);
            
            if (emp is null)
            {
                result.AddError(ErrorCode.NotFound, 
                    string.Format(DocumentErrorMessages.CommentNotFound, request.ID));
                
                return result;
            }

            //if (emp.HMSID != request.UserProfileId)
            //{
            //    result.AddError(ErrorCode.PostDeleteNotPossible, EmployeesErrorMessages.EmployeeDeleteNotPossible);
            //    return result;
            //}

            _ctx.DMS_Comments.Remove(emp);
            await _ctx.SaveChangesAsync(cancellationToken);

            result.Payload = emp;
        }
        catch (Exception e)
        {
            result.AddUnknownError(e.Message);
        }

        return result;
    }
}