﻿
using KeyBankHMS.Application.Enums;
using KeyBankHMS.Application.Models;
using KeyBankHMS.Application.Comments.Queries;
using KeyBankHMS.Dal;
using MediatR;
using Microsoft.EntityFrameworkCore;

using KeyBankHMS.Domain.Aggregates.CommentAggregate;

namespace KeyBankHMS.Application.Comments.QueryHandlers;

public class GetAllDocumentsHandler : IRequestHandler<GetAllDocuments, OperationResult<List<DMS_Comments>>>
{
    private readonly DataContext _ctx;
    public GetAllDocumentsHandler(DataContext ctx)
    {
        _ctx = ctx;
    }
    public async Task<OperationResult<List<DMS_Comments>>> Handle(GetAllDocuments request, CancellationToken cancellationToken)
    {
        var result = new OperationResult<List<DMS_Comments>>();
        try
        {
            var posts = await _ctx.DMS_Comments.ToListAsync();
            result.Payload = posts;
        }
        catch (Exception e)
        {
            result.AddUnknownError(e.Message);
        }

        return result;
    }
}