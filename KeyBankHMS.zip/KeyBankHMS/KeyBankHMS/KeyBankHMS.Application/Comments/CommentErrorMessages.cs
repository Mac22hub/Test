﻿namespace KeyBankHMS.Application.Comments;

public class DocumentErrorMessages
{
    public const string CommentNotFound = "No Comment found with ID {0}";
    public const string CommentDeleteNotPossible = "Only the owner of a Comment can delete it";

    public const string CommentUpdateNotPossible =
        "Comment update not possible because it's not the Comment owner that initiates the update";

    public const string CommentInteractionNotFound = "Interaction not found";
    public const string InteractionRemovalNotAuthorized = "Cannot remove interaction as you are not its author";
    public const string CommentCommentNotFound = "Comment not found";
    public const string CommentRemovalNotAuthorized = "Cannot remove comment from Comment as you are not its author";
}