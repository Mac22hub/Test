﻿using KeyBankHMS.Domain.Aggregates.CommentAggregate;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KeyBankHMS.Dal.Configurations
{
    internal class CommentConfig : IEntityTypeConfiguration<DMS_Comments>
    {
        public void Configure(EntityTypeBuilder<DMS_Comments> builder)
        {
            builder.HasKey(pc => pc.ID);
        }
    }
}
