﻿using KeyBankHMS.Api.Contracts.Comments;
using KeyBankHMS.Api.Contracts.Comments.Requests;
using KeyBankHMS.Application.Comments.Commands;
using KeyBankHMS.Application.Comments.Queries;


namespace KeyBankHMS.Api.Controllers.V1
{

    //[Authorize( AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class CommentController : BaseController
    {
        [HttpGet]
        [Route(ApiRoutes.Comment.GetAllComments)]
        public async Task<IActionResult> GetAllComments(CancellationToken cancellationToken)
        {
            var result = await _mediator.Send(new GetAllDocuments(), cancellationToken);
            return result.IsError ? HandleErrorResponse(result.Errors) : Ok(result);

        }

        [HttpPost]
        [Route(ApiRoutes.Comment.AddComment)]
        [ValidateModel]
        public async Task<IActionResult> AddComment([FromBody] CommentCreate newEmp, CancellationToken cancellationToken)
        {
            var command = new CreateComment()
            {
                ID = newEmp.ID,
                CommentText = newEmp.CommentText,
                HMSID = newEmp.HMSID,
                DocumentID = newEmp.DocumentID,
                CreatedBy = newEmp.CreatedBy,
                Modified = newEmp.Modified,
                ModifiedBy = newEmp.ModifiedBy
            };
            var result = await _mediator.Send(command, cancellationToken);
            return result.IsError ? HandleErrorResponse(result.Errors) : Ok(result);
        }


        [HttpGet]
        [Route(ApiRoutes.Comment.GetCommentById)]
        [ValidateGuid("id")]
        public async Task<IActionResult> GetCommentById(string id, CancellationToken cancellationToken)
        {
            var empId = Guid.Parse(id);
            var query = new GetDocumentById() { ID = empId };
            var result = await _mediator.Send(query, cancellationToken);
            return result.IsError ? HandleErrorResponse(result.Errors) : Ok(result);
        }

        [HttpPatch]
        [Route(ApiRoutes.Comment.UpdateCommentById)]
        [ValidateGuid("id")]
        [ValidateModel]
        public async Task<IActionResult> UpdateCommentById([FromBody] CommentUpdate updatedComment, string id, CancellationToken cancellationToken)
        {
            var command = new UpdateDocument()
            {
                ID = updatedComment.ID,
                CommentText = updatedComment.CommentText,
                HMSID = updatedComment.HMSID,
                DocumentID = updatedComment.DocumentID,
                CreatedBy = updatedComment.CreatedBy,
                Modified = updatedComment.Modified,
                ModifiedBy = updatedComment.ModifiedBy
            };

            var result = await _mediator.Send(command, cancellationToken);
            return result.IsError ? HandleErrorResponse(result.Errors) : NoContent();
        }

        [HttpDelete]
        [Route(ApiRoutes.Comment.DeleteComment)]
        [ValidateGuid("id")]
        public async Task<IActionResult> DeleteComment(string id, CancellationToken cancellationToken)
        {
            var empId = Guid.Parse(id);
            var command = new DeleteComment() { HMSID = empId };
            var result = await _mediator.Send(command, cancellationToken);
            return result.IsError ? HandleErrorResponse(result.Errors) : NoContent();
        }
    }
}
