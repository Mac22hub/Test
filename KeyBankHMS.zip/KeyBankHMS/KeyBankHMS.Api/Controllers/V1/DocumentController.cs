﻿using KeyBankHMS.Api.Contracts.Documents;

using KeyBankHMS.Api.Contracts.Documents.Requests;
using KeyBankHMS.Application.Documents.Commands;
using KeyBankHMS.Application.Documents.Queries;


namespace KeyBankHMS.Api.Controllers.V1
{

    //[Authorize( AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class DocumentController : BaseController
    {
        [HttpGet]
        [Route(ApiRoutes.Document.GetAllDocuments)]
        public async Task<IActionResult> GetAllDocuments(CancellationToken cancellationToken)
        {
            var result = await _mediator.Send(new GetAllDocuments(), cancellationToken);
            return result.IsError ? HandleErrorResponse(result.Errors) : Ok(result);

        }

        
        [HttpPost]
        [Route(ApiRoutes.Document.AddDocument)]
        [ValidateModel]
        public async Task<IActionResult> AddDocument([FromBody] DocumentCreate newEmp, CancellationToken cancellationToken)
        {
            var command = new CreateDocument()
            {
                ID = newEmp.ID,
                Name = newEmp.Name,
                HMSID = newEmp.HMSID,
                DocumentTypeID = newEmp.DocumentTypeID,
                DropOffDate = newEmp.DropOffDate,
                DroppedOffBy = newEmp.DroppedOffBy,
                DocumentDate = newEmp.DocumentDate,
                PageCount = newEmp.PageCount,
                Author = newEmp.Author,
                PublishedDate = newEmp.PublishedDate,
                TrashedDate = newEmp.TrashedDate,
                TrashedBy = newEmp.TrashedBy,
                SPUrl = newEmp.SPUrl,
                RetainedUntil = newEmp.RetainedUntil,
                Created = newEmp.Created,
                CreatedBy = newEmp.CreatedBy,
                Modified = newEmp.Modified,
                ModifiedBy = newEmp.ModifiedBy
            };

            var result = await _mediator.Send(command, cancellationToken);
            return result.IsError ? HandleErrorResponse(result.Errors) : Ok(result);
        }


        [HttpGet]
        [Route(ApiRoutes.Document.GetDocumentById)]
        [ValidateGuid("id")]
        public async Task<IActionResult> GetDocumentById(string id, CancellationToken cancellationToken)
        {
            var empId = Guid.Parse(id);
            var query = new GetDocumentById() { HMSID = empId };

            var result = await _mediator.Send(query, cancellationToken);
            return result.IsError ? HandleErrorResponse(result.Errors) : Ok(result);
        }

        [HttpPatch]
        [Route(ApiRoutes.Document.UpdateDocumentById)]
        [ValidateGuid("id")]
        [ValidateModel]
        public async Task<IActionResult> UpdateDocumentById([FromBody] DocumentUpdate updatedDocument, string id, CancellationToken cancellationToken)
        {
            var command = new UpdateDocument()
            {

                ID = updatedDocument.ID,
                Name = updatedDocument.Name,
                HMSID = updatedDocument.HMSID,
                DocumentTypeID = updatedDocument.DocumentTypeID,
                DropOffDate = updatedDocument.DropOffDate,
                DroppedOffBy = updatedDocument.DroppedOffBy,
                DocumentDate = updatedDocument.DocumentDate,
                PageCount = updatedDocument.PageCount,
                Author = updatedDocument.Author,
                PublishedDate = updatedDocument.PublishedDate,
                TrashedDate = updatedDocument.TrashedDate,
                TrashedBy = updatedDocument.TrashedBy,
                SPUrl = updatedDocument.SPUrl,
                RetainedUntil = updatedDocument.RetainedUntil,
                Created = updatedDocument.Created,
                CreatedBy = updatedDocument.CreatedBy,
                Modified = updatedDocument.Modified,
                ModifiedBy = updatedDocument.ModifiedBy

            };
            var result = await _mediator.Send(command, cancellationToken);
            return result.IsError ? HandleErrorResponse(result.Errors) : NoContent();
        }

        [HttpDelete]
        [Route(ApiRoutes.Document.DeleteDocument)]
        [ValidateGuid("id")]
        public async Task<IActionResult> DeleteDocument(string id, CancellationToken cancellationToken)
        {
            var empId = Guid.Parse(id);
            var command = new DeleteDocument() { HMSID = empId };
            var result = await _mediator.Send(command, cancellationToken);
            return result.IsError ? HandleErrorResponse(result.Errors) : NoContent();
        }

    }
}
