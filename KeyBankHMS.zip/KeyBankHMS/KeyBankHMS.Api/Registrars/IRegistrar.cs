﻿namespace KeyBankHMS.Api.Registrars
{
    public interface IRegistrar
    {
    }
}
