﻿using PostInteraction = KeyBankHMS.Domain.Aggregates.PostAggregate.PostInteraction;

namespace KeyBankHMS.Api.MappingProfiles;

public class PostMappings : Profile
{
    public PostMappings()
    {
        CreateMap<Post, PostResponse>();
        CreateMap<PostComment, PostCommentResponse>();
        CreateMap<PostInteraction, KeyBankHMS.Api.Contracts.Posts.Responses.PostInteraction>()
            .ForMember(dest 
                => dest.Type, opt 
                => opt.MapFrom(src 
                => src.InteractionType.ToString()))
            .ForMember(dest => dest.Author, opt 
            => opt.MapFrom(src => src.UserProfile));
    }
}