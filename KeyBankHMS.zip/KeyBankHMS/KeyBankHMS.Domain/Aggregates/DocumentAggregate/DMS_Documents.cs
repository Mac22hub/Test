﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KeyBankHMS.Domain.Aggregates.UserProfileAggregate;
using KeyBankHMS.Domain.Exceptions;
using KeyBankHMS.Domain.Validators.PostValidators;

namespace KeyBankHMS.Domain.Aggregates.DocumentAggregate
{
    public class DMS_Documents
    {
       
        public DMS_Documents()
        {
        }
        public Guid ID { get; set; }
        public string Name { get; set; }
        public Guid HMSID { get; set; }
        public int DocumentTypeID { get; set; }
        public DateTime DropOffDate { get; set; }
        public string DroppedOffBy { get; set; }
        public DateTime DocumentDate { get; set; }
        public string PageCount { get; set; }
        public string Author { get; set; }
        public DateTime PublishedDate { get; set; }
        public DateTime TrashedDate { get; set; }
        public string TrashedBy { get; set; }
        public string SPUrl { get; set; }
        public DateTime RetainedUntil { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime Modified { get; set; }
        public string ModifiedBy { get; set; }

        ////Factories
        ///// <summary>
        ///// Creates a new post instance
        ///// </summary>
        ///// <param name="userProfileId">User profile ID</param>
        ///// <param name="textContent">Post content</param>
        ///// <returns><see cref="Post"/></returns>
        ///// <exception cref="PostNotValidException"></exception>
        //public static Employee CreateEmployee(Guid HMSID)
        public static DMS_Documents CreateDocument(DMS_Documents obj)
        {
            var objectToValidate = new DMS_Documents
            {
                //HMSID = HMSID,

                //IdentifierTypeId = newEmp.IdentifierTypeId,
                //NameInHR = newEmp.NameInHR,
                //FirstName = newEmp.FirstName,
                //MiddleName = newEmp.MiddleName,
                //LastName = newEmp.LastName,
                //EmployeeID = newEmp.EmployeeID,
                //EmployeeStatus = newEmp.EmployeeStatus,
                //OriginalHireDate = newEmp.OriginalHireDate,
                //MostRecentHireDate = newEmp.MostRecentHireDate,
                //TerminationDate = newEmp.TerminationDate,
                //SSN = newEmp.SSN,
                //RACFID = newEmp.RACFID,
                //Gender = newEmp.Gender,
                //DateOfBirth = newEmp.DateOfBirth,
                //JobTitle = newEmp.JobTitle,
                //JobTitleAsOf = newEmp.JobTitleAsOf,
                //JobCode = newEmp.JobCode,
                //CompensationChange = newEmp.CompensationChange,
                //Company = newEmp.Company,
                //CostCenter = newEmp.CostCenter,
                //BankNumber = newEmp.BankNumber,
                //ManagerRACFID = newEmp.ManagerRACFID,
                //Manager = newEmp.Manager,
                //WorkPhone = newEmp.WorkPhone,
                //Email = newEmp.Email,
                //WorkAddress = newEmp.WorkAddress,
                //WorkCity = newEmp.WorkCity,
                //WorkState = newEmp.WorkState,
                //MBU = newEmp.MBU,
                //EBU = newEmp.EBU,
                //SBU = newEmp.SBU,
                //LegacyCompany = newEmp.LegacyCompany,
                //WorkspaceCategory = newEmp.WorkspaceCategory,
                //HRBP = newEmp.HRBP,
                //Created = newEmp.Created,
                //CreatedBy = newEmp.CreatedBy,
                //Modified = newEmp.Modified,
                //ModifiedBy = newEmp.ModifiedBy
            };

            //var validationResult = validator.Validate(objectToValidate);

            //if (validationResult.IsValid)
                return objectToValidate;

            //var exception = new EmployeeNotValidException("Employee is not valid");
            //validationResult.Errors.ForEach(vr => exception.ValidationErrors.Add(vr.ErrorMessage));
            //throw exception;
        }

        ////public methods
        ///// <summary>
        ///// Updates the post text
        ///// </summary>
        ///// <param name="newText">The updated post text</param>
        ///// <exception cref="PostNotValidException"></exception>
        //public void UpdatePostText(string newText)
        //{
        //    if (string.IsNullOrWhiteSpace(newText))
        //    {
        //        var exception = new PostNotValidException("Cannot update post." +
        //                                                  "Post text is not valid");
        //        exception.ValidationErrors.Add("The provided text is either null or contains only white space");
        //        throw exception;
        //    }
        //    TextContent = newText;
        //    LastModified = DateTime.UtcNow;
        //}

        //public void AddPostComment(PostComment newComment)
        //{
        //    _comments.Add(newComment);
        //}

        //public void RemoveComment(PostComment toRemove)
        //{
        //    _comments.Remove(toRemove);
        //}

        //public void UpdatePostComment(Guid postCommentId, string updatedComment)
        //{
        //    var comment = _comments.FirstOrDefault(c => c.CommentId == postCommentId);
        //    if (comment != null && !string.IsNullOrWhiteSpace(updatedComment))
        //        comment.UpdateCommentText(updatedComment);
        //}

        //public void AddInteraction(PostInteraction newInteraction)
        //{
        //    _interactions.Add(newInteraction);
        //}

        //public void RemoveInteraction(PostInteraction toRemove)
        //{
        //    _interactions.Remove(toRemove);
        //}

    }
}
