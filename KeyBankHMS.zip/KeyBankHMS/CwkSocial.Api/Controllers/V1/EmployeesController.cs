﻿using KeyBankHMS.Api.Contracts.Employee;
using KeyBankHMS.Api.Contracts.Employee.Requests;
using KeyBankHMS.Application.Employees.Commands;
using KeyBankHMS.Application.Employees.Queries;
//using KeyBankHMS.Application.Employees.Commands;

namespace KeyBankHMS.Api.Controllers.V1
{

    //[Authorize( AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class EmployeesController : BaseController
    {
        [HttpGet]
        [Route(ApiRoutes.Employee.GetAllEmployees)]
        public async Task<IActionResult> GetAllEmployees(CancellationToken cancellationToken)
        {
            var result = await _mediator.Send(new GetAllEmployees(), cancellationToken);
            //var mapped = _mapper.Map<List<EmployeeResponse>>(result.Payload);
            return result.IsError ? HandleErrorResponse(result.Errors) : Ok(result);

        }

        //[HttpPost]
        //[ValidateModel]
        [HttpPost]
        [Route(ApiRoutes.Employee.AddEmployee)]
        [ValidateModel]
        public async Task<IActionResult> AddEmployee ([FromBody] EmployeeCreate newEmp, CancellationToken cancellationToken)
        {
            var command = new CreateEmployee()
            {
                IdentifierTypeId = newEmp.IdentifierTypeId,
                NameInHR = newEmp.NameInHR,
                FirstName = newEmp.FirstName,
                MiddleName = newEmp.MiddleName,
                LastName = newEmp.LastName,
                EmployeeID = newEmp.EmployeeID,
                EmployeeStatus = newEmp.EmployeeStatus,
                OriginalHireDate = newEmp.OriginalHireDate,
                MostRecentHireDate = newEmp.MostRecentHireDate,
                TerminationDate = newEmp.TerminationDate,
                SSN = newEmp.SSN,
                RACFID = newEmp.RACFID,
                Gender = newEmp.Gender,
                DateOfBirth = newEmp.DateOfBirth,
                JobTitle = newEmp.JobTitle,
                JobTitleAsOf = newEmp.JobTitleAsOf,
                JobCode = newEmp.JobCode,
                CompensationChange = newEmp.CompensationChange,
                Company = newEmp.Company,
                CostCenter = newEmp.CostCenter,
                BankNumber = newEmp.BankNumber,
                ManagerRACFID = newEmp.ManagerRACFID,
                Manager = newEmp.Manager,
                WorkPhone = newEmp.WorkPhone,
                Email = newEmp.Email,
                WorkAddress = newEmp.WorkAddress,
                WorkCity = newEmp.WorkCity,
                WorkState = newEmp.WorkState,
                MBU = newEmp.MBU,
                EBU = newEmp.EBU,
                SBU = newEmp.SBU,
                LegacyCompany = newEmp.LegacyCompany,
                WorkspaceCategory = newEmp.WorkspaceCategory,
                HRBP = newEmp.HRBP,
                Created = newEmp.Created,
                CreatedBy = newEmp.CreatedBy,
                Modified = newEmp.Modified,
                ModifiedBy = newEmp.ModifiedBy
            };
            
            var result = await _mediator.Send(command, cancellationToken);
            //var mapped = _mapper.Map<EmployeeResponse>(result.Payload);
            //return result.IsError ? HandleErrorResponse(result.Errors) : CreatedAtAction(nameof(GetById), new { id = result.Payload.HMSID }, result);
            return result.IsError? HandleErrorResponse(result.Errors) : Ok(result);
        }


        [HttpGet]
        [Route(ApiRoutes.Employee.GetEmployeeById)]
        [ValidateGuid("id")]
        public async Task<IActionResult> GetEmployeeById(string id, CancellationToken cancellationToken)
        {
            var empId = Guid.Parse(id);
            //var query = new GetPostById() { PostId = postId };
             var query = new GetEmployeeById() { HMSID = empId };
            
            var result = await _mediator.Send(query, cancellationToken);
            //var mapped = _mapper.Map<EmployeeResponse>(result.Payload);
            return result.IsError ? HandleErrorResponse(result.Errors) : Ok(result);
        }

        [HttpPatch]
        [Route(ApiRoutes.Employee.UpdateEmployeeById)]
        [ValidateGuid("id")]
        [ValidateModel]
        public async Task<IActionResult> UpdateEmployeeById([FromBody] EmployeeUpdate updatedEmployee, string id, CancellationToken cancellationToken)
        {
            //var userProfileId = HttpContext.GetUserProfileIdClaimValue();

            var command = new UpdateEmployee()
            {
                //NewText = updatedEmployee.Text,
                //PostId = Guid.Parse(id),
                //UserProfileId = userProfileId
                HMSID = Guid.Parse(id),
                IdentifierTypeId = updatedEmployee.IdentifierTypeId,
                NameInHR = updatedEmployee.NameInHR,
                FirstName = updatedEmployee.FirstName,
                MiddleName = updatedEmployee.MiddleName,
                LastName = updatedEmployee.LastName,
                EmployeeID = updatedEmployee.EmployeeID,
                EmployeeStatus = updatedEmployee.EmployeeStatus,
                OriginalHireDate = updatedEmployee.OriginalHireDate,
                MostRecentHireDate = updatedEmployee.MostRecentHireDate,
                TerminationDate = updatedEmployee.TerminationDate,
                SSN = updatedEmployee.SSN,
                RACFID = updatedEmployee.RACFID,
                Gender = updatedEmployee.Gender,
                DateOfBirth = updatedEmployee.DateOfBirth,
                JobTitle = updatedEmployee.JobTitle,
                JobTitleAsOf = updatedEmployee.JobTitleAsOf,
                JobCode = updatedEmployee.JobCode,
                CompensationChange = updatedEmployee.CompensationChange,
                Company = updatedEmployee.Company,
                CostCenter = updatedEmployee.CostCenter,
                BankNumber = updatedEmployee.BankNumber,
                ManagerRACFID = updatedEmployee.ManagerRACFID,
                Manager = updatedEmployee.Manager,
                WorkPhone = updatedEmployee.WorkPhone,
                Email = updatedEmployee.Email,
                WorkAddress = updatedEmployee.WorkAddress,
                WorkCity = updatedEmployee.WorkCity,
                WorkState = updatedEmployee.WorkState,
                MBU = updatedEmployee.MBU,
                EBU = updatedEmployee.EBU,
                SBU = updatedEmployee.SBU,
                LegacyCompany = updatedEmployee.LegacyCompany,
                WorkspaceCategory = updatedEmployee.WorkspaceCategory,
                HRBP = updatedEmployee.HRBP,
                Created = updatedEmployee.Created,
                CreatedBy = updatedEmployee.CreatedBy,
                Modified = updatedEmployee.Modified,
                ModifiedBy = updatedEmployee.ModifiedBy

            };
                //EmployeeUpdate obj = new EmployeeUpdate();
                //obj.HMSID = Guid.Parse(id);
                //updatedEmployee.HMSID = Guid.Parse(id);
               // var command = _mapper.Map<UpdateEmployee>(updatedEmployee);
            var result = await _mediator.Send(command, cancellationToken);

            return result.IsError ? HandleErrorResponse(result.Errors) : NoContent();
        }

        [HttpDelete]
        [Route(ApiRoutes.Employee.DeleteEmployee)]
        [ValidateGuid("id")]
        public async Task<IActionResult> DeleteEmployee(string id, CancellationToken cancellationToken)
        {
            var empId = Guid.Parse(id);
            //var userProfileId = HttpContext.GetUserProfileIdClaimValue();
            //var command = new DeleteEmployee() { EmployeeID = Guid.Parse(id), UserProfileId = userProfileId };
            var command = new DeleteEmployee() { HMSID = empId };
            var result = await _mediator.Send(command, cancellationToken);

            return result.IsError ? HandleErrorResponse(result.Errors) : NoContent();
        }

    }
}
