﻿namespace KeyBankHMS.Api.Contracts.Comments.Requests;

public class CommentUpdate
{
    public Guid ID { get; set; }
    public string CommentText { get; set; }
    public Guid HMSID { get;  set; }
    public int DocumentID { get; set; }
    public DateTime Created { get; set; }
    public string CreatedBy { get; set; }
    public DateTime Modified { get; set; }
    public string ModifiedBy { get; set; }
}