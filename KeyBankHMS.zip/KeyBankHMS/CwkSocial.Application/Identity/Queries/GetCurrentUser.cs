﻿using System.Security.Claims;
using KeyBankHMS.Application.Identity.Dtos;
using KeyBankHMS.Application.Models;
using MediatR;

namespace KeyBankHMS.Application.Identity.Queries;

public class GetCurrentUser : IRequest<OperationResult<IdentityUserProfileDto>>
{
    public Guid UserProfileId { get; set; }
    public ClaimsPrincipal ClaimsPrincipal { get; set; }
}