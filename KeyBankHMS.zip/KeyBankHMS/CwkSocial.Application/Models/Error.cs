﻿using KeyBankHMS.Application.Enums;

namespace KeyBankHMS.Application.Models;

public class Error
{
    public ErrorCode Code { get; set; }
    public string Message { get; set; }
}