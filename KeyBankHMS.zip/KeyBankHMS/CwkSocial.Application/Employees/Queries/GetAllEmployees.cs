﻿using KeyBankHMS.Domain.Aggregates.EmployeeAggregate;
using KeyBankHMS.Application.Models;
using MediatR;

namespace KeyBankHMS.Application.Employees.Queries;

public class GetAllEmployees : IRequest<OperationResult<List<HMS_Employee>>>
{
    
}