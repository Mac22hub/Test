﻿using KeyBankHMS.Domain.Aggregates.EmployeeAggregate;
using KeyBankHMS.Application.Enums;
using KeyBankHMS.Application.Models;
using KeyBankHMS.Application.Employees.Queries;
using KeyBankHMS.Dal;
using MediatR;
using Microsoft.EntityFrameworkCore;
using KeyBankHMS.Application.Employees;

namespace KeyBankHMS.Application.Employees.QueryHandlers;

public class GetEmployeeByIdHandler : IRequestHandler<GetEmployeeById, OperationResult<HMS_Employee>>
{
    private readonly DataContext _ctx;
    public GetEmployeeByIdHandler(DataContext ctx)
    {
        _ctx = ctx;
    }
    public async Task<OperationResult<HMS_Employee>> Handle(GetEmployeeById request, CancellationToken cancellationToken)
    {
        var result = new OperationResult<HMS_Employee>();
        var emp = await _ctx.HMS_Employee.FirstOrDefaultAsync(p => p.HMSID == request.HMSID);

        


        if (emp is null)
        {
            result.AddError(ErrorCode.NotFound, 
                string.Format(EmployeesErrorMessages.EmployeeNotFound, request.HMSID));
            return result;
        }

        result.Payload = emp;
        return result;
    }
}