﻿using KeyBankHMS.Domain.Aggregates.EmployeeAggregate;
using KeyBankHMS.Application.Enums;
using KeyBankHMS.Application.Models;
using KeyBankHMS.Application.Posts.Commands;
using KeyBankHMS.Dal;
using MediatR;
using Microsoft.EntityFrameworkCore;
using KeyBankHMS.Application.Employees.Commands;

namespace KeyBankHMS.Application.Employees.CommandHandlers;

public class DeleteEmployeeHandler : IRequestHandler<DeleteEmployee, OperationResult<HMS_Employee>>
{
    private readonly DataContext _ctx;

    public DeleteEmployeeHandler(DataContext ctx)
    {
        _ctx = ctx;
    }
    
    public async Task<OperationResult<HMS_Employee>> Handle(DeleteEmployee request, CancellationToken cancellationToken)
    {
        var result = new OperationResult<HMS_Employee>();
        try
        {
            var emp = await _ctx.HMS_Employee.FirstOrDefaultAsync(p => p.HMSID == request.HMSID, cancellationToken: cancellationToken);
            
            if (emp is null)
            {
                result.AddError(ErrorCode.NotFound, 
                    string.Format(EmployeesErrorMessages.EmployeeNotFound, request.HMSID));
                
                return result;
            }

            if (emp.HMSID != request.UserProfileId)
            {
                result.AddError(ErrorCode.PostDeleteNotPossible, EmployeesErrorMessages.EmployeeDeleteNotPossible);
                return result;
            }

            _ctx.HMS_Employee.Remove(emp);
            await _ctx.SaveChangesAsync(cancellationToken);

            result.Payload = emp;
        }
        catch (Exception e)
        {
            result.AddUnknownError(e.Message);
        }

        return result;
    }
}