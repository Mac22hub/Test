﻿using KeyBankHMS.Domain.Aggregates.EmployeeAggregate;
using KeyBankHMS.Application.Models;
using MediatR;

namespace KeyBankHMS.Application.Employees.Commands;

public class DeleteEmployee : IRequest<OperationResult<HMS_Employee>>
{
    public Guid HMSID { get; set; }
    public string EmployeeID { get; set; }
    public Guid UserProfileId { get; set; }
}