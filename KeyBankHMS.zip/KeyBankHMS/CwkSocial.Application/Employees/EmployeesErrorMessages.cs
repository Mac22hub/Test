﻿namespace KeyBankHMS.Application.Employees;

public class EmployeesErrorMessages
{
    public const string EmployeeNotFound = "No Employee found with ID {0}";
    public const string EmployeeDeleteNotPossible = "Only the owner of a Employee can delete it";

    public const string EmployeeUpdateNotPossible =
        "Employee update not possible because it's not the Employee owner that initiates the update";

    public const string EmployeeInteractionNotFound = "Interaction not found";
    public const string InteractionRemovalNotAuthorized = "Cannot remove interaction as you are not its author";
    public const string EmployeeCommentNotFound = "Comment not found";
    public const string CommentRemovalNotAuthorized = "Cannot remove comment from Employee as you are not its author";
}