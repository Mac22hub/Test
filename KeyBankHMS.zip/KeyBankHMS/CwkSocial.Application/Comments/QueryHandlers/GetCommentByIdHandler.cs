﻿using KeyBankHMS.Domain.Aggregates.CommentAggregate;
using KeyBankHMS.Application.Enums;
using KeyBankHMS.Application.Models;
using KeyBankHMS.Application.Comments.Queries;
using KeyBankHMS.Dal;
using MediatR;
using Microsoft.EntityFrameworkCore;
using KeyBankHMS.Application.Comments;
using KeyBankHMS.Application.Comments.Queries;

namespace KeyBankHMS.Application.Comments.QueryHandlers;

public class GetDocumentByIdHandler : IRequestHandler<GetDocumentById, OperationResult<DMS_Comments>>
{
    private readonly DataContext _ctx;
    public GetDocumentByIdHandler(DataContext ctx)
    {
        _ctx = ctx;
    }
    public async Task<OperationResult<DMS_Comments>> Handle(GetDocumentById request, CancellationToken cancellationToken)
    {
        var result = new OperationResult<DMS_Comments>();
        var emp = await _ctx.DMS_Comments.FirstOrDefaultAsync(p => p.ID == request.ID);

        


        if (emp is null)
        {
            result.AddError(ErrorCode.NotFound, 
                string.Format(DocumentErrorMessages.CommentNotFound, request.HMSID));
            return result;
        }

        result.Payload = emp;
        return result;
    }
}