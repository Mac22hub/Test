﻿using KeyBankHMS.Domain.Aggregates.CommentAggregate;
using KeyBankHMS.Application.Models;
using MediatR;

namespace KeyBankHMS.Application.Comments.Commands;

public class DeleteComment : IRequest<OperationResult<DMS_Comments>>
{
    public Guid HMSID { get; set; }
    public Guid ID { get; set; }
    public Guid UserProfileId { get; set; }
}