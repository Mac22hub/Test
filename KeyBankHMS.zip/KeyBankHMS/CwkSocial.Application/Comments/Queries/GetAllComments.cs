﻿using KeyBankHMS.Domain.Aggregates.CommentAggregate;
using KeyBankHMS.Application.Models;
using MediatR;

namespace KeyBankHMS.Application.Comments.Queries;

public class GetAllDocuments : IRequest<OperationResult<List<DMS_Comments>>>
{
    
}