﻿using KeyBankHMS.Domain.Aggregates.DocumentAggregate;
using KeyBankHMS.Application.Models;
using MediatR;

namespace KeyBankHMS.Application.Documents.Queries;

public class GetAllDocuments : IRequest<OperationResult<List<DMS_Documents>>>
{
    
}