﻿using KeyBankHMS.Domain.Aggregates.DocumentAggregate;
using KeyBankHMS.Domain.Exceptions;
using KeyBankHMS.Application.Enums;
using KeyBankHMS.Application.Models;
using KeyBankHMS.Application.Documents.Commands;
using KeyBankHMS.Dal;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace KeyBankHMS.Application.Documents.CommandHandlers;

public class UpdateDocumentHandler : IRequestHandler<UpdateDocument, OperationResult<DMS_Documents>>
{
    private readonly DataContext _ctx;

    public UpdateDocumentHandler(DataContext ctx)
    {
        _ctx = ctx;
    }
    
    public async Task<OperationResult<DMS_Documents>> Handle(UpdateDocument request, CancellationToken cancellationToken)
    {
        var result = new OperationResult<DMS_Documents>();

        try
        {
            var obj = await _ctx.DMS_Documents.FirstOrDefaultAsync(p => p.ID == request.ID, cancellationToken: cancellationToken);

            //if (emp is null)
            //{
            //    result.AddError(ErrorCode.NotFound, 
            //        string.Format(CommentErrorMessages.CommentNotFound, request.ID));
            //    return result;
            //}


            obj.ID = request.ID;
            obj.Name = request.Name;
            obj.HMSID = request.HMSID;
            obj.DocumentTypeID = request.DocumentTypeID;
            obj.DropOffDate = request.DropOffDate;
            obj.DroppedOffBy = request.DroppedOffBy;
            obj.DocumentDate = request.DocumentDate;
            obj.PageCount = request.PageCount;
            obj.Author = request.Author;
            obj.PublishedDate = request.PublishedDate;
            obj.TrashedDate = request.TrashedDate;
            obj.TrashedBy = request.TrashedBy;
            obj.SPUrl = request.SPUrl;
            obj.RetainedUntil = request.RetainedUntil;
            obj.Created = request.Created;
            obj.CreatedBy = request.CreatedBy;
            obj.Modified = request.Modified;
            obj.ModifiedBy = request.ModifiedBy;
            await _ctx.SaveChangesAsync(cancellationToken);
            result.Payload = obj;
        }
        
        catch (PostNotValidException e)
        {
            e.ValidationErrors.ForEach(er => result.AddError(ErrorCode.ValidationError, er));
        }
        catch (Exception e)
        {
            result.AddUnknownError(e.Message);
        }

        return result;
    }
}