﻿using KeyBankHMS.Domain.Aggregates.DocumentAggregate;
using KeyBankHMS.Domain.Exceptions;
using KeyBankHMS.Application.Enums;
using KeyBankHMS.Application.Models;
using KeyBankHMS.Dal;
using MediatR;
using KeyBankHMS.Application.Documents.Commands;

namespace KeyBankHMS.Application.Documents.CommandHandlers;

public class CreateDocumentHandler : IRequestHandler<CreateDocument, OperationResult<DMS_Documents>>
{
    private readonly DataContext _ctx;

    public CreateDocumentHandler(DataContext ctx)
    {
        _ctx = ctx;
    }
    
    public async Task<OperationResult<DMS_Documents>> Handle(CreateDocument request, CancellationToken cancellationToken)
    {
        var result = new OperationResult<DMS_Documents>();
        try
        {
            DMS_Documents obj = new DMS_Documents();
            obj.ID = request.ID;
            obj.Name = request.Name;
            obj.HMSID = request.HMSID;
            obj.DocumentTypeID = request.DocumentTypeID;
            obj.DropOffDate = request.DropOffDate;
            obj.DroppedOffBy = request.DroppedOffBy;
            obj.DocumentDate = request.DocumentDate;
            obj.PageCount = request.PageCount;
            obj.Author = request.Author;
            obj.PublishedDate = request.PublishedDate;
            obj.TrashedDate = request.TrashedDate;
            obj.TrashedBy = request.TrashedBy;
            obj.SPUrl = request.SPUrl;
            obj.RetainedUntil = request.RetainedUntil;
            obj.Created = request.Created;
            obj.CreatedBy = request.CreatedBy;
            obj.Modified = request.Modified;
            obj.ModifiedBy = request.ModifiedBy;

            _ctx.DMS_Documents.Add(obj);
            await _ctx.SaveChangesAsync(cancellationToken);
            result.Payload = obj;
        }
        catch (PostNotValidException e)
        {
            e.ValidationErrors.ForEach(er => result.AddError(ErrorCode.ValidationError, er));
        }

        catch (Exception e)
        {
            result.AddUnknownError(e.Message);
        }
        
        return result;
    }
}