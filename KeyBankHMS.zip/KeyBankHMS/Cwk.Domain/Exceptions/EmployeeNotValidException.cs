﻿namespace KeyBankHMS.Domain.Exceptions;

public class EmployeeNotValidException : NotValidException
{
    internal EmployeeNotValidException() {}
    internal EmployeeNotValidException(string message) : base(message) {}
    internal EmployeeNotValidException(string message, Exception inner) : base(message, inner) {}
}