﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KeyBankHMS.Domain.Aggregates.UserProfileAggregate;
using KeyBankHMS.Domain.Exceptions;
using KeyBankHMS.Domain.Validators.PostValidators;

namespace KeyBankHMS.Domain.Aggregates.EmployeeAggregate
{
    public class HMS_Employee
    {
       
        public HMS_Employee()
        {
        }
        public Guid HMSID { get; private set; }
        public int IdentifierTypeId { get; set; }
        public string NameInHR { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string EmployeeID { get; set; }
        public string EmployeeStatus { get; set; }
        public DateTime OriginalHireDate { get; set; }
        public DateTime MostRecentHireDate { get; set; }
        public DateTime TerminationDate { get; set; }
        public string SSN { get; set; }
        public string RACFID { get; set; }
        public string Gender { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string JobTitle { get; set; }
        public DateTime JobTitleAsOf { get; set; }
        public string JobCode { get; set; }
        public DateTime CompensationChange { get; set; }
        public string Company { get; set; }
        public string CostCenter { get; set; }
        public string BankNumber { get; set; }
        public string ManagerRACFID { get; set; }
        public string Manager { get; set; }
        public string WorkPhone { get; set; }
        public string Email { get; set; }
        public string WorkAddress { get; set; }
        public string WorkCity { get; set; }
        public string WorkState { get; set; }
        public string MBU { get; set; }
        public string EBU { get; set; }
        public string SBU { get; set; }
        public string LegacyCompany { get; set; }
        public string WorkspaceCategory { get; set; }
        public string HRBP { get; set; }
        public DateTime Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime Modified { get; set; }
        public string ModifiedBy { get; set; }

        ////Factories
        ///// <summary>
        ///// Creates a new post instance
        ///// </summary>
        ///// <param name="userProfileId">User profile ID</param>
        ///// <param name="textContent">Post content</param>
        ///// <returns><see cref="Post"/></returns>
        ///// <exception cref="PostNotValidException"></exception>
        //public static Employee CreateEmployee(Guid HMSID)
        public static HMS_Employee CreateEmployee(HMS_Employee obj)
        {
            var objectToValidate = new HMS_Employee
            {
                //HMSID = HMSID,

                //IdentifierTypeId = newEmp.IdentifierTypeId,
                //NameInHR = newEmp.NameInHR,
                //FirstName = newEmp.FirstName,
                //MiddleName = newEmp.MiddleName,
                //LastName = newEmp.LastName,
                //EmployeeID = newEmp.EmployeeID,
                //EmployeeStatus = newEmp.EmployeeStatus,
                //OriginalHireDate = newEmp.OriginalHireDate,
                //MostRecentHireDate = newEmp.MostRecentHireDate,
                //TerminationDate = newEmp.TerminationDate,
                //SSN = newEmp.SSN,
                //RACFID = newEmp.RACFID,
                //Gender = newEmp.Gender,
                //DateOfBirth = newEmp.DateOfBirth,
                //JobTitle = newEmp.JobTitle,
                //JobTitleAsOf = newEmp.JobTitleAsOf,
                //JobCode = newEmp.JobCode,
                //CompensationChange = newEmp.CompensationChange,
                //Company = newEmp.Company,
                //CostCenter = newEmp.CostCenter,
                //BankNumber = newEmp.BankNumber,
                //ManagerRACFID = newEmp.ManagerRACFID,
                //Manager = newEmp.Manager,
                //WorkPhone = newEmp.WorkPhone,
                //Email = newEmp.Email,
                //WorkAddress = newEmp.WorkAddress,
                //WorkCity = newEmp.WorkCity,
                //WorkState = newEmp.WorkState,
                //MBU = newEmp.MBU,
                //EBU = newEmp.EBU,
                //SBU = newEmp.SBU,
                //LegacyCompany = newEmp.LegacyCompany,
                //WorkspaceCategory = newEmp.WorkspaceCategory,
                //HRBP = newEmp.HRBP,
                //Created = newEmp.Created,
                //CreatedBy = newEmp.CreatedBy,
                //Modified = newEmp.Modified,
                //ModifiedBy = newEmp.ModifiedBy
            };

            //var validationResult = validator.Validate(objectToValidate);

            //if (validationResult.IsValid)
                return objectToValidate;

            //var exception = new EmployeeNotValidException("Employee is not valid");
            //validationResult.Errors.ForEach(vr => exception.ValidationErrors.Add(vr.ErrorMessage));
            //throw exception;
        }

        ////public methods
        ///// <summary>
        ///// Updates the post text
        ///// </summary>
        ///// <param name="newText">The updated post text</param>
        ///// <exception cref="PostNotValidException"></exception>
        //public void UpdatePostText(string newText)
        //{
        //    if (string.IsNullOrWhiteSpace(newText))
        //    {
        //        var exception = new PostNotValidException("Cannot update post." +
        //                                                  "Post text is not valid");
        //        exception.ValidationErrors.Add("The provided text is either null or contains only white space");
        //        throw exception;
        //    }
        //    TextContent = newText;
        //    LastModified = DateTime.UtcNow;
        //}

        //public void AddPostComment(PostComment newComment)
        //{
        //    _comments.Add(newComment);
        //}

        //public void RemoveComment(PostComment toRemove)
        //{
        //    _comments.Remove(toRemove);
        //}

        //public void UpdatePostComment(Guid postCommentId, string updatedComment)
        //{
        //    var comment = _comments.FirstOrDefault(c => c.CommentId == postCommentId);
        //    if (comment != null && !string.IsNullOrWhiteSpace(updatedComment))
        //        comment.UpdateCommentText(updatedComment);
        //}

        //public void AddInteraction(PostInteraction newInteraction)
        //{
        //    _interactions.Add(newInteraction);
        //}

        //public void RemoveInteraction(PostInteraction toRemove)
        //{
        //    _interactions.Remove(toRemove);
        //}

    }
}
