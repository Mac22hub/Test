﻿using KeyBankHMS.Domain.Aggregates.PostAggregate;
using FluentValidation;

namespace KeyBankHMS.Domain.Validators.PostValidators;

public class EmployeeValidator : AbstractValidator<Post>
{
    public EmployeeValidator()
    {
        RuleFor(p => p.TextContent)
            .NotNull().WithMessage("Employee text content can't be null")
            .NotEmpty().WithMessage("Employee text content can't be empty");
    }
}