﻿using KeyBankHMS.Domain.Aggregates.PostAggregate;
using KeyBankHMS.Domain.Aggregates.DocumentAggregate;
using KeyBankHMS.Domain.Aggregates.UserProfileAggregate;
using KeyBankHMS.Dal.Configurations;
using KeyBankHMS.Dal.Extensions;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using KeyBankHMS.Domain.Aggregates.EmployeeAggregate;
using KeyBankHMS.Domain.Aggregates.CommentAggregate;

namespace KeyBankHMS.Dal
{
    public class DataContext : IdentityDbContext
    {
        public DataContext(DbContextOptions options) : base(options)    
        {
        }

        public DbSet<UserProfile> UserProfiles { get; set; }
        public DbSet<Post> Posts { get; set; }
        public DbSet<HMS_Employee> HMS_Employee { get; set; }
        public DbSet<DMS_Comments> DMS_Comments { get; set; }
        public DbSet<DMS_Documents> DMS_Documents { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyAllConfigurations();
            base.OnModelCreating(modelBuilder);
        }
    }
}
