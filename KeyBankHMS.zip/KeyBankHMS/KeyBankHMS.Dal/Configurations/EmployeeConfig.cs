﻿using KeyBankHMS.Domain.Aggregates.EmployeeAggregate;
using KeyBankHMS.Domain.Aggregates.PostAggregate;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KeyBankHMS.Dal.Configurations
{
    internal class EmployeeConfig : IEntityTypeConfiguration<HMS_Employee>
    {
        public void Configure(EntityTypeBuilder<HMS_Employee> builder)
        {
            builder.HasKey(pc => pc.HMSID);
        }
    }
}
