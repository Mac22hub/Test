﻿using KeyBankHMS.Domain.Aggregates.DocumentAggregate;
using KeyBankHMS.Domain.Aggregates.PostAggregate;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KeyBankHMS.Dal.Configurations
{
    internal class DocumentConfig : IEntityTypeConfiguration<DMS_Documents>
    {
        public void Configure(EntityTypeBuilder<DMS_Documents> builder)
        {
            builder.HasKey(pc => pc.ID);
        }
    }
}
