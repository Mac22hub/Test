﻿using KeyBankHMS.Domain.Aggregates.CommentAggregate;
using KeyBankHMS.Domain.Exceptions;
using KeyBankHMS.Application.Enums;
using KeyBankHMS.Application.Models;
using KeyBankHMS.Application.Comments.Commands;
using KeyBankHMS.Dal;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace KeyBankHMS.Application.Comments.CommandHandlers;

public class UpdateEmployeeHandler : IRequestHandler<UpdateDocument, OperationResult<DMS_Comments>>
{
    private readonly DataContext _ctx;

    public UpdateEmployeeHandler(DataContext ctx)
    {
        _ctx = ctx;
    }
    
    public async Task<OperationResult<DMS_Comments>> Handle(UpdateDocument request, CancellationToken cancellationToken)
    {
        var result = new OperationResult<DMS_Comments>();

        try
        {
            var emp = await _ctx.DMS_Comments.FirstOrDefaultAsync(p => p.ID == request.ID, cancellationToken: cancellationToken);
            
            if (emp is null)
            {
                result.AddError(ErrorCode.NotFound, 
                    string.Format(DocumentErrorMessages.CommentNotFound, request.ID));
                return result;
            }

            emp.ID = request.ID;
            emp.CommentText = request.CommentText;
            emp.HMSID = request.HMSID;
            emp.DocumentID = request.DocumentID;
            emp.Created = request.Created;
            emp.CreatedBy = request.CreatedBy;
            emp.Modified = request.Modified;
            emp.ModifiedBy = request.ModifiedBy;
            
            await _ctx.SaveChangesAsync(cancellationToken);

            result.Payload = emp;
        }
        
        catch (PostNotValidException e)
        {
            e.ValidationErrors.ForEach(er => result.AddError(ErrorCode.ValidationError, er));
        }
        catch (Exception e)
        {
            result.AddUnknownError(e.Message);
        }

        return result;
    }
}