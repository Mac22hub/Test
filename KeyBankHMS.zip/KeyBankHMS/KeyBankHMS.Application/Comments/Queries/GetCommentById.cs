﻿using KeyBankHMS.Domain.Aggregates.CommentAggregate;
using KeyBankHMS.Application.Models;
using MediatR;

namespace KeyBankHMS.Application.Comments.Queries;

public class GetDocumentById : IRequest<OperationResult<DMS_Comments>>
{
    public Guid HMSID { get; set; }
    public Guid ID { get; set; }
}