﻿using KeyBankHMS.Domain.Aggregates.PostAggregate;
using KeyBankHMS.Application.Models;
using MediatR;

namespace KeyBankHMS.Application.Posts.Commands;

public class RemovePostInteraction : IRequest<OperationResult<PostInteraction>>
{
    public Guid PostId { get; set; }
    public Guid InteractionId { get; set; }
    public Guid UserProfileId { get; set; }
}