﻿
using KeyBankHMS.Application.Enums;
using KeyBankHMS.Application.Models;
using KeyBankHMS.Application.Documents.Queries;
using KeyBankHMS.Dal;
using MediatR;
using Microsoft.EntityFrameworkCore;

using KeyBankHMS.Domain.Aggregates.DocumentAggregate;

namespace KeyBankHMS.Application.Documents.QueryHandlers;

public class GetAllDocumentsHandler : IRequestHandler<GetAllDocuments, OperationResult<List<DMS_Documents>>>
{
    private readonly DataContext _ctx;
    public GetAllDocumentsHandler(DataContext ctx)
    {
        _ctx = ctx;
    }
    public async Task<OperationResult<List<DMS_Documents>>> Handle(GetAllDocuments request, CancellationToken cancellationToken)
    {
        var result = new OperationResult<List<DMS_Documents>>();
        try
        {
            var posts = await _ctx.DMS_Documents.ToListAsync();
            result.Payload = posts;
        }
        catch (Exception e)
        {
            result.AddUnknownError(e.Message);
        }

        return result;
    }
}