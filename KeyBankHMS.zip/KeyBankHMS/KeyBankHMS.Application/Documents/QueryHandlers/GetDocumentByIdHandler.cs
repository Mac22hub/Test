﻿using KeyBankHMS.Domain.Aggregates.DocumentAggregate;
using KeyBankHMS.Application.Enums;
using KeyBankHMS.Application.Models;
using KeyBankHMS.Application.Documents.Queries;
using KeyBankHMS.Dal;
using MediatR;
using Microsoft.EntityFrameworkCore;
using KeyBankHMS.Application.Comments;


namespace KeyBankHMS.Application.Documents.QueryHandlers;

public class GetDocumentByIdHandler : IRequestHandler<GetDocumentById, OperationResult<DMS_Documents>>
{
    private readonly DataContext _ctx;
    public GetDocumentByIdHandler(DataContext ctx)
    {
        _ctx = ctx;
    }
    public async Task<OperationResult<DMS_Documents>> Handle(GetDocumentById request, CancellationToken cancellationToken)
    {
        var result = new OperationResult<DMS_Documents>();
        var emp = await _ctx.DMS_Documents.FirstOrDefaultAsync(p => p.ID == request.ID);

        


        if (emp is null)
        {
            //result.AddError(ErrorCode.NotFound, 
            //    string.Format(CommentErrorMessages.CommentNotFound, request.HMSID));
            return result;
        }

        result.Payload = emp;
        return result;
    }
}