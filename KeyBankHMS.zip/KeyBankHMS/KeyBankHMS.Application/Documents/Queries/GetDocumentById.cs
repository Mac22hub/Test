﻿using KeyBankHMS.Domain.Aggregates.DocumentAggregate;
using KeyBankHMS.Application.Models;
using MediatR;

namespace KeyBankHMS.Application.Documents.Queries;

public class GetDocumentById : IRequest<OperationResult<DMS_Documents>>
{
    public Guid HMSID { get; set; }
    public Guid ID { get; set; }
}