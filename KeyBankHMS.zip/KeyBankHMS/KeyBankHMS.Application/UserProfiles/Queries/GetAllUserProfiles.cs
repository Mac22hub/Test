﻿using KeyBankHMS.Domain.Aggregates.UserProfileAggregate;
using KeyBankHMS.Application.Models;
using MediatR;


namespace KeyBankHMS.Application.UserProfiles.Queries
{
    public class GetAllUserProfiles : IRequest<OperationResult<IEnumerable<UserProfile>>>
    {
    }
}
