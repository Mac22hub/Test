﻿
using KeyBankHMS.Application.Enums;
using KeyBankHMS.Application.Models;
using KeyBankHMS.Application.Employees.Queries;
using KeyBankHMS.Dal;
using MediatR;
using Microsoft.EntityFrameworkCore;

using KeyBankHMS.Domain.Aggregates.EmployeeAggregate;

namespace KeyBankHMS.Application.Employees.QueryHandlers;

public class GetAllEmployeesHandler : IRequestHandler<GetAllEmployees, OperationResult<List<HMS_Employee>>>
{
    private readonly DataContext _ctx;
    public GetAllEmployeesHandler(DataContext ctx)
    {
        _ctx = ctx;
    }
    public async Task<OperationResult<List<HMS_Employee>>> Handle(GetAllEmployees request, CancellationToken cancellationToken)
    {
        var result = new OperationResult<List<HMS_Employee>>();
        try
        {
            var posts = await _ctx.HMS_Employee.ToListAsync();
            result.Payload = posts;
        }
        catch (Exception e)
        {
            result.AddUnknownError(e.Message);
        }

        return result;
    }
}