import * as React from 'react';
import styles from './KeyBankHms.module.scss';
import Search from './Search';


export default class UserHome extends React.Component<{name}> {




    state = {
        currentPage : "UserHome"
    }
    changeScreen = () => {
        this.setState({ currentPage: "UserHome" })
       
    }


    public render(): React.ReactElement<{name}> {




        return (
            <div>
                {this.state.currentPage === "UserHome" &&
                <div>
                <div style = {{ display: "flex"}}  className={styles.mainHeader} >
                    <div>
                    <span>HMS Employee Information</span>
                    </div>
                    <div>
                    <span style={{  paddingLeft: "420px"}}>Welcome, {this.props.name}</span>
                    </div>
                    
                </div>
                <div onClick={() => this.setState({ currentPage: "search" })}>
                    <div style={{marginTop: "30px" , marginLeft: "300px"}} className={styles.employeeCard}>
                        <h3>Search employees</h3>
                        
                    </div>
                </div>
                </div>
                }
                {
                 this.state.currentPage === "search" &&  
                 <Search changeScreenHome={this.changeScreen}/>
                }
            </div>
        );
    }
}
