/* tslint:disable */
require('./KeyBankHms.module.css');
const styles = {
  keyBankHms: 'keyBankHms_a478bbc4',
  container: 'container_a478bbc4',
  row: 'row_a478bbc4',
  column: 'column_a478bbc4',
  'ms-Grid': 'ms-Grid_a478bbc4',
  title: 'title_a478bbc4',
  subTitle: 'subTitle_a478bbc4',
  description: 'description_a478bbc4',
  button: 'button_a478bbc4',
  label: 'label_a478bbc4',
  mainHeader: 'mainHeader_a478bbc4',
  userBanner: 'userBanner_a478bbc4',
  userDetails: 'userDetails_a478bbc4',
  anotherBranchButton: 'anotherBranchButton_a478bbc4',
  employeeCard: 'employeeCard_a478bbc4',
  userCards: 'userCards_a478bbc4',
  searchCard: 'searchCard_a478bbc4',
  homeIcon: 'homeIcon_a478bbc4',
  tableCard: 'tableCard_a478bbc4',
  loginCard: 'loginCard_a478bbc4',
  displayCard: 'displayCard_a478bbc4',
  searchButton: 'searchButton_a478bbc4',
  'custom-file-upload': 'custom-file-upload_a478bbc4',
  employeeDisplayCard: 'employeeDisplayCard_a478bbc4',
  maintenanceCard: 'maintenanceCard_a478bbc4',
  nameLink: 'nameLink_a478bbc4',
};

export default styles;
/* tslint:enable */