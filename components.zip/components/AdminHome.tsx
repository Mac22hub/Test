import * as React from 'react';
import styles from './KeyBankHms.module.scss';
import Maintenance from './Maintenance';
import Search from './Search';


export default class AdminHome extends React.Component<{ name }> {
    state = {

        currentPage: "AdminHome"
    }
    changeScreen = () => {
        this.setState({ currentPage: "AdminHome" })
       
    }
    public render(): React.ReactElement<{ name }> {
        return (
            <div>
                {this.state.currentPage == "AdminHome" &&
                    <div>
                        <div style={{ display: "flex" }} className={styles.mainHeader} >
                            <span>HMS Employee Information</span>
                            <span style={{ paddingLeft: "430px" }}>Welcome, {this.props.name}</span>

                        </div>
                        <div>
                            <div style={{ marginTop: '30px' }} className={styles.displayCard}>
                                <div  onClick={() => this.setState({currentPage: "search" })} className={styles.employeeCard}>
                                    <h3>Search employees</h3>
                                </div>
                                <div className={styles.employeeCard}>
                                    <h3>Upload Documents</h3>
                                </div>
                                <div className={styles.employeeCard}>
                                    <h3>Assign My Documents</h3>
                                </div>
                            </div>
                            <div style={{ marginTop: '30px' }} className={styles.displayCard}>
                                <div className={styles.employeeCard}>
                                    <h3>Assign all Documents</h3>
                                </div>
                                <div className={styles.employeeCard}>
                                    <h3>Reporting</h3>
                                </div>
                                <div className={styles.employeeCard}  onClick={() => this.setState({ currentPage: "maintenance" })}>
                                    <h3>Maintenance</h3>
                                </div>
                            </div>
                        </div>
                    </div>}
                {this.state.currentPage === "search" && <Search changeScreenHome={this.changeScreen} />}
                {this.state.currentPage === "maintenance" && <Maintenance changeScreen={this.changeScreen} />}
            </div>
        );
    }
}
