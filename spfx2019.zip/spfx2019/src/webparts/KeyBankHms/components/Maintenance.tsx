import * as React from 'react';
import styles from './KeyBankHms.module.scss';
import Search from './Search';


export default class Maintenance extends React.Component<{ changeScreen }> {
    state = {

        currentPage: "Maintenance"
    }

    public render(): React.ReactElement<{ changeScreen }> {
        return (
            <div>
                {this.state.currentPage == "Maintenance" &&
                    <div>
                        <div>
                            <div className={styles.mainHeader}>
                                <button className={styles.homeIcon} onClick={this.props.changeScreen}>home</button>
                                <span>HMS Employee Information</span>
                            </div>
                        </div>
                        <div>
                            <div style={{ marginTop: '30px' }} className={styles.displayCard}>
                                <div onClick={() => this.setState({ currentPage: "search" })} className={styles.maintenanceCard}>
                                    <h3>Recently Deleted</h3>
                                </div>
                                <div className={styles.maintenanceCard}>
                                    <h3>Create new Document Types</h3>
                                </div>
                            </div>
                            <div style={{ marginTop: '30px' }} className={styles.displayCard}>
                                <div className={styles.maintenanceCard}>
                                    <h3>Record Hold</h3>
                                </div>
                                <div className={styles.maintenanceCard}>
                                    <h3>Purge Files</h3>
                                </div>
                            </div>
                        </div>
                    </div>}

            </div>
        );
    }
}
