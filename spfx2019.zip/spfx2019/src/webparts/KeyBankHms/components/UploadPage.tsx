import * as React from 'react';
import styles from './KeyBankHms.module.scss';

const tableKeyMapping = {
    EEID: "EE ID",
    documentType: "Document Type",
    date: "Date",
    documentDate: "Document Date",
    comments: "Comments",
    chooseFile: "Choose file"
}

export default class UploadPage extends React.Component<{}> {


    state = {
        currentPage: "uploadPage",
        tableDetails: {
            EEID: "EE ID",
            documentType: "Drop down",
            date: "System date",
            documentDate: "Text field",
            comments: "Text field",
            chooseFile: "Browse PC"

        }
    }


    public render(): React.ReactElement<{}> {

        return (

            <div>

                {
                    this.state.currentPage === "uploadPage" &&
                    <div>
                        <div>
                            <div className={styles.mainHeader}>
                                <span>HMS Employee Information</span>
                            </div>
                        </div>

                        <div style={{ marginTop: "50px", width: '100%' ,display: "flex" , alignItems :"center" , justifyContent:"center" }} >

                            <table style={{border : "2px solid black" , borderSpacing:"0px"}}>
                                <tbody>
                                    {Object.keys(this.state.tableDetails).map(key => 
                                        <tr style={{border : "1px solid " ,padding : "5px"}}>
                                            <td style={{border : "1px solid " ,padding : "5px" }}>{tableKeyMapping[key]}</td>
                                            {this.state.tableDetails[key] !== "Browse PC" ?
                                                <td style={{border : "1px solid " ,padding : "5px" }}>{this.state.tableDetails[key]}</td>
                                           :
                                                <td style={{border : "1px solid "  ,padding : "5px"}}><button>{this.state.tableDetails[key]}</button></td>
                                            } 
                                        </tr>
                                    )
                                    }
                                </tbody>
                            </table>
                        </div>
                    </div>

                }



            </div>
        );
    }
}
