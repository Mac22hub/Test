/// <reference types="react" />
import * as React from 'react';
export default class UserHome extends React.Component<{
    name;
}> {
    state: {
        currentPage: string;
    };
    changeScreen: () => void;
    render(): React.ReactElement<{
        name;
    }>;
}
