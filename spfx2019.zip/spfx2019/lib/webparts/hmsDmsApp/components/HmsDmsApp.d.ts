/// <reference types="react" />
import * as React from 'react';
import { IHmsDmsAppProps } from './IHmsDmsProps';
export default class HmsDmsApp extends React.Component<IHmsDmsAppProps, {}> {
    state: {
        username: string;
        password: string;
        isLogin: boolean;
    };
    handleClick: () => void;
    render(): React.ReactElement<IHmsDmsAppProps>;
}
