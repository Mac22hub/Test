export interface IKeyBankHmsProps {
    description: string;
}
