/// <reference types="react" />
import * as React from 'react';
import { IKeyBankHmsProps } from './IKeyBankHms';
export default class HmsDmsApp extends React.Component<IKeyBankHmsProps, {}> {
    state: {
        username: string;
        password: string;
        isLogin: boolean;
    };
    handleClick: () => void;
    render(): React.ReactElement<IKeyBankHmsProps>;
}
