/// <reference types="react" />
import * as React from 'react';
export default class UploadPage extends React.Component<{}> {
    state: {
        currentPage: string;
        tableDetails: {
            EEID: string;
            documentType: string;
            date: string;
            documentDate: string;
            comments: string;
            chooseFile: string;
        };
    };
    render(): React.ReactElement<{}>;
}
