/// <reference types="react" />
import * as React from 'react';
import { IKeyBankHmsProps } from './IKeyBankHmsProps';
export default class UserLogin extends React.Component<IKeyBankHmsProps, {}> {
    state: {
        username: string;
        password: string;
    };
    render(): React.ReactElement<IKeyBankHmsProps>;
}
