﻿using ExcelDataReader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

namespace ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DataTable dt = null;
            string fullfilepath = @"C:\Users\Documents\Repo_ConsoleApp\DataBook.xlsx";
            using (var stream = File.Open(fullfilepath, FileMode.Open, FileAccess.Read))
            {
                IExcelDataReader reader;
                reader = ExcelDataReader.ExcelReaderFactory.CreateReader(stream);
                //// reader.IsFirstRowAsColumnNames
                var conf = new ExcelDataSetConfiguration
                {
                    ConfigureDataTable = _ => new ExcelDataTableConfiguration
                    {
                        UseHeaderRow = true
                    }
                };
                var dataSet = reader.AsDataSet(conf);
                // Now you can get data from each sheet by its index or its "name"
                var dataTable = dataSet.Tables[0];
                dt = dataSet.Tables[0];
                DataTable table = new DataTable();
                table.Columns.Add("IdentifierTypeId", typeof(string));
                table.Columns.Add("NameInHR ", typeof(string));
                table.Columns.Add("FirstName", typeof(string));
                table.Columns.Add("MiddleName", typeof(string));
                table.Columns.Add("LastName ", typeof(string));
                table.Columns.Add("EmployeeID", typeof(string));
                table.Columns.Add("EmployeeStatus", typeof(string));
                table.Columns.Add("OriginalHireDate", typeof(DateTime));
                table.Columns.Add("MostRecentHireDate", typeof(DateTime));
                table.Columns.Add("TerminationDate", typeof(DateTime));
                table.Columns.Add("SSN", typeof(int));
                table.Columns.Add("RACFID", typeof(string));
                table.Columns.Add("Gender", typeof(string));
                table.Columns.Add("DateOfBirth", typeof(DateTime));
                table.Columns.Add("JobTitle", typeof(string));
                table.Columns.Add("JobTitleAsOf", typeof(DateTime));
                table.Columns.Add("JobCode", typeof(string));
                table.Columns.Add("CompensationChangeDate", typeof(DateTime));
                table.Columns.Add("Company", typeof(string));
                table.Columns.Add("CostCenter", typeof(string));
                table.Columns.Add("BankNumber", typeof(string));
                table.Columns.Add("ManagerRACFID", typeof(string));
                table.Columns.Add("Manager", typeof(string));
                table.Columns.Add("WorkPhone", typeof(string));
                table.Columns.Add("Email", typeof(string));
                table.Columns.Add("WorkAddress", typeof(string));
                table.Columns.Add("WorkCity", typeof(string));
                table.Columns.Add("WorkState", typeof(string));
                table.Columns.Add("MBU", typeof(string));
                table.Columns.Add("EBU", typeof(string));
                table.Columns.Add("SBU", typeof(string));
                table.Columns.Add("LegacyCompany", typeof(string));
                table.Columns.Add("WorkspaceCategory", typeof(string));
                table.Columns.Add("HRBP", typeof(string));
                table.Columns.Add("Created", typeof(DateTime));
                table.Columns.Add("CreatedBy", typeof(string));
                table.Columns.Add("Modified", typeof(DateTime));
                table.Columns.Add("ModifiedBy", typeof(string));
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DataRow row = table.NewRow();
                    row["IdentifierTypeId"] = dt.Rows[i]["IdentifierTypeId"];
                    row["NameInHR "] = dt.Rows[i]["NameInHR"];
                    row["FirstName"] = dt.Rows[i]["FirstName"];
                    row["MiddleName"] = dt.Rows[i]["MiddleName"];
                    row["LastName "] = dt.Rows[i]["LastName"];
                    row["EmployeeID"] = dt.Rows[i]["EmployeeID"];
                    row["EmployeeStatus"] = dt.Rows[i]["EmployeeStatus"];
                    row["OriginalHireDate"] = dt.Rows[i]["OriginalHireDate"];
                    row["MostRecentHireDate"] = dt.Rows[i]["MostRecentHireDate"];
                    row["TerminationDate"] = dt.Rows[i]["TerminationDate"];
                    row["SSN"] = dt.Rows[i]["SSN"];
                    row["RACFID"] = dt.Rows[i]["RACFID"];
                    row["Gender"] = dt.Rows[i]["Gender"];
                    row["DateOfBirth"] = dt.Rows[i]["DateOfBirth"];
                    row["JobTitle"] = dt.Rows[i]["JobTitle"];
                    row["JobTitleAsOf"] = dt.Rows[i]["JobTitleAsOf"];
                    row["JobCode"] = dt.Rows[i]["JobCode"];
                    row["CompensationChangeDate"] = dt.Rows[i]["CompensationChangeDate"];
                    row["Company"] = dt.Rows[i]["Company"];
                    row["CostCenter"] = dt.Rows[i]["CostCenter"];
                    row["BankNumber"] = dt.Rows[i]["BankNumber"];
                    row["ManagerRACFID"] = dt.Rows[i]["ManagerRACFID"];
                    row["Manager"] = dt.Rows[i]["Manager"];
                    row["WorkPhone"] = dt.Rows[i]["WorkPhone"];
                    row["Email"] = dt.Rows[i]["Email"];
                    row["WorkAddress"] = dt.Rows[i]["WorkAddress"];
                    row["WorkCity"] = dt.Rows[i]["WorkCity"];
                    row["WorkState"] = dt.Rows[i]["WorkState"];
                    row["MBU"] = dt.Rows[i]["MBU"];
                    row["EBU"] = dt.Rows[i]["EBU"];
                    row["SBU"] = dt.Rows[i]["SBU"];
                    row["LegacyCompany"] = dt.Rows[i]["LegacyCompany"];
                    row["WorkspaceCategory"] = dt.Rows[i]["WorkspaceCategory"];
                    row["HRBP"] = dt.Rows[i]["HRBP"];
                    row["Created"] = dt.Rows[i]["Created"];
                    row["CreatedBy"] = dt.Rows[i]["CreatedBy"];
                    row["Modified"] = dt.Rows[i]["Modified"];
                    row["ModifiedBy"] = dt.Rows[i]["ModifiedBy"];
                    table.Rows.Add(row);
                }

                if (table.Rows.Count > 0)
                {
                    string consString = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
                    using (SqlConnection con = new SqlConnection(consString))
                    {
                        using (SqlCommand cmd = new SqlCommand("USP_Insert_STG_HMS_Employee"))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Connection = con;   
                            cmd.Parameters.AddWithValue("@UT_HMS_Employee_param", table);
                            con.Open();
                            cmd.ExecuteNonQuery();
                            con.Close();
                        }
                    }
                }
            }

        }
    }
}
