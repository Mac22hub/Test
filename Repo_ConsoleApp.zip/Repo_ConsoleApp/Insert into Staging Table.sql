USE [HMSDB]
GO

/****** Object:  StoredProcedure [dbo].[USP_Insert_STG_HMS_Employee]    Script Date: 7/1/2022 1:59:06 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- select * from [HMS_Employees]
CREATE PROCEDURE [dbo].[USP_Insert_STG_HMS_Employee](@UT_HMS_Employee_param UT_HMS_Employee ReadOnly)


AS  
BEGIN  

INSERT INTO [dbo].[STG_HMS_Employees] 
           ([IdentifierTypeId]
           ,[NameInHR]
           ,[FirstName]
           ,[MiddleName]
           ,[LastName]
           ,[EmployeeID]
           ,[EmployeeStatus]
           ,[OriginalHireDate]
           ,[MostRecentHireDate]
           ,[TerminationDate]
           ,[SSN]
           ,[RACFID]
           ,[Gender]
           ,[DateOfBirth]
           ,[JobTitle]
           ,[JobTitleAsOf]
           ,[JobCode]
           ,[CompensationChangeDate]
           ,[Company]
           ,[CostCenter]
           ,[BankNumber]
           ,[ManagerRACFID]
           ,[Manager]
           ,[WorkPhone]
           ,[Email]
           ,[WorkAddress]
           ,[WorkCity]
           ,[WorkState]
           ,[MBU]
           ,[EBU]
           ,[SBU]
           ,[LegacyCompany]
           ,[WorkspaceCategory]
           ,[HRBP]
           ,[Created]
           ,[CreatedBy]
           ,[Modified]
           ,[ModifiedBy]
		   )
   SELECT
   --*
   [IdentifierTypeId]
           ,[NameInHR]
           ,[FirstName]
           ,[MiddleName]
           ,[LastName]
           ,[EmployeeID]
           ,[EmployeeStatus]
           ,[OriginalHireDate]
           ,[MostRecentHireDate]
           ,[TerminationDate]
           ,[SSN]
           ,[RACFID]
           ,[Gender]
           ,[DateOfBirth]
           ,[JobTitle]
           ,[JobTitleAsOf]
           ,[JobCode]
           ,[CompensationChangeDate]
           ,[Company]
           ,[CostCenter]
           ,[BankNumber]
           ,[ManagerRACFID]
           ,[Manager]
           ,[WorkPhone]
           ,[Email]
           ,[WorkAddress]
           ,[WorkCity]
           ,[WorkState]
           ,[MBU]
           ,[EBU]
           ,[SBU]
           ,[LegacyCompany]
           ,[WorkspaceCategory]
           ,[HRBP]
           ,[Created]
           ,[CreatedBy]
           ,[Modified]
           ,[ModifiedBy]
   FROM @UT_HMS_Employee_param  
END  


GO


