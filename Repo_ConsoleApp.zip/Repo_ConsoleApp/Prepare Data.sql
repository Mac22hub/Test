USE [HMSDB]
GO

/****** Object:  StoredProcedure [dbo].[USP_PrepareData]    Script Date: 7/1/2022 1:59:56 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- EXEC [USP_PrepareData]
--SELECT * FROM TEMP_HMS_Employees
-- TRUNCATE TABLE TEMP_HMS_Employees
-- =============================================
CREATE PROCEDURE [dbo].[USP_PrepareData] 
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
 
	--INSERT INTO #Temp  SELECT * STG_HMS_Employees FROM WHERE EmployeeID in @EmployeeID
	INSERT INTO TEMP_HMS_Employees SELECT *,'Update' FROM HMS_Employees	EXCEPT SELECT *,'Update' FROM STG_HMS_Employees
	
     
	
	INSERT INTO TEMP_HMS_Employees SELECT *,'Insert'  FROM STG_HMS_Employees WHERE EmployeeID IN (SELECT EmployeeID FROM STG_HMS_Employees WHERE EmployeeID NOT IN (SELECT EmployeeID FROM HMS_Employees))
	
	
	
	--INSERT INTO TEMP_HMS_Employees SELECT *,'Delete'  FROM HMS_Employees WHERE EmployeeID IN (SELECT EmployeeID FROM HMS_Employees WHERE EmployeeID NOT IN (SELECT EmployeeID FROM STG_HMS_Employees))
	
END
GO


