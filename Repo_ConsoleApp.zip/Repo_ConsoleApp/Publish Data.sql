USE [HMSDB]
GO

/****** Object:  StoredProcedure [dbo].[USP_PublishData]    Script Date: 7/1/2022 2:00:11 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- exec USP_PublishData
-- =============================================
CREATE PROCEDURE [dbo].[USP_PublishData] 
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	
	-- INSERT LOGIC
	INSERT INTO HMS_Employees 	SELECT  IdentifierTypeId,NameInHR,	FirstName,	MiddleName,	LastName ,	EmployeeID,	EmployeeStatus ,	OriginalHireDate ,	MostRecentHireDate,	TerminationDate,	SSN ,	RACFID ,	Gender ,	DateOfBirth ,	JobTitle ,	JobTitleAsOf ,	JobCode ,	CompensationChangeDate,	Company ,	CostCenter ,	BankNumber ,	ManagerRACFID,	Manager ,	WorkPhone ,	Email ,	WorkAddress ,	WorkCity ,	WorkState ,	MBU ,	EBU ,	SBU ,	LegacyCompany ,	WorkspaceCategory ,	HRBP ,	Created ,	CreatedBy ,	Modified ,	ModifiedBy 	 FROM TEMP_HMS_Employees Where  OperationType = 'Insert'

	-- DELETE LOGIC
	DELETE FROM HMS_Employees WHERE EmployeeID IN (SELECT EmployeeID FROM TEMP_HMS_Employees Where  OperationType = 'Delete')


	-- UPDATE LOGIC
	DECLARE 
    @EmployeeID VARCHAR(MAX)
    --@list_price   DECIMAL;

	DECLARE cursor_EmpID CURSOR
	FOR 
	SELECT EmployeeID FROM TEMP_HMS_Employees WHERE OperationType = 'Update'

	OPEN cursor_EmpID;

	FETCH NEXT FROM cursor_EmpID INTO 
		@EmployeeID

	WHILE @@FETCH_STATUS = 0
		BEGIN
			--PRINT @EmployeeID 
			--SELECT * FROM TEMP_HMS_Employees Where EmployeeID = @EmployeeID AND OperationType = 'Update'
			--SELECT * FROM TEMP_HMS_Employees Where EmployeeID = @EmployeeID 

			

			UPDATE HMS_Employees 
			SET 
				HMS_Employees.IdentifierTypeId     = TEMP_HMS_Employees.IdentifierTypeId,
				HMS_Employees.NameInHR             = TEMP_HMS_Employees.NameInHR,
				HMS_Employees.FirstName            = TEMP_HMS_Employees.FirstName,
				HMS_Employees.MiddleName           = TEMP_HMS_Employees.MiddleName,
				HMS_Employees.LastName             = TEMP_HMS_Employees.LastName,
				HMS_Employees.EmployeeID           = TEMP_HMS_Employees.EmployeeID,
				HMS_Employees.EmployeeStatus       = TEMP_HMS_Employees.EmployeeStatus,
				HMS_Employees.OriginalHireDate     = TEMP_HMS_Employees.OriginalHireDate,
				HMS_Employees.MostRecentHireDate   = TEMP_HMS_Employees.MostRecentHireDate,
				HMS_Employees.TerminationDate      = TEMP_HMS_Employees.TerminationDate,
				HMS_Employees.SSN                  = TEMP_HMS_Employees.SSN,
				HMS_Employees.RACFID               = TEMP_HMS_Employees.RACFID,
				HMS_Employees.Gender               = TEMP_HMS_Employees.Gender,
				HMS_Employees.DateOfBirth          = TEMP_HMS_Employees.DateOfBirth,
				HMS_Employees.JobTitle             = TEMP_HMS_Employees.JobTitle,
				HMS_Employees.JobTitleAsOf         = TEMP_HMS_Employees.JobTitleAsOf,
				HMS_Employees.JobCode              = TEMP_HMS_Employees.JobCode,
				HMS_Employees.CompensationChangeDate   = TEMP_HMS_Employees.CompensationChangeDate,
				HMS_Employees.Company              = TEMP_HMS_Employees.Company,
				HMS_Employees.CostCenter           = TEMP_HMS_Employees.CostCenter,
				HMS_Employees.BankNumber           = TEMP_HMS_Employees.BankNumber,
				HMS_Employees.ManagerRACFID        = TEMP_HMS_Employees.ManagerRACFID,
				HMS_Employees.Manager              = TEMP_HMS_Employees.Manager,
				HMS_Employees.WorkPhone            = TEMP_HMS_Employees.WorkPhone,
				HMS_Employees.Email                = TEMP_HMS_Employees.Email,
				HMS_Employees.WorkAddress          = TEMP_HMS_Employees.WorkAddress,
				HMS_Employees.WorkCity             = TEMP_HMS_Employees.WorkCity,
				HMS_Employees.WorkState            = TEMP_HMS_Employees.WorkState,
				HMS_Employees.MBU                  = TEMP_HMS_Employees.MBU,
				HMS_Employees.EBU                  = TEMP_HMS_Employees.EBU,
				HMS_Employees.SBU                  = TEMP_HMS_Employees.SBU,
				HMS_Employees.LegacyCompany        = TEMP_HMS_Employees.LegacyCompany,
				HMS_Employees.WorkspaceCategory    = TEMP_HMS_Employees.WorkspaceCategory,
				HMS_Employees.HRBP                 = TEMP_HMS_Employees.HRBP,
				HMS_Employees.Created              = TEMP_HMS_Employees.Created,
				HMS_Employees.CreatedBy            = TEMP_HMS_Employees.CreatedBy,
				HMS_Employees.Modified             = TEMP_HMS_Employees.Modified,
				HMS_Employees.ModifiedBy           = TEMP_HMS_Employees.ModifiedBy
			FROM TEMP_HMS_Employees, HMS_Employees 
			WHERE HMS_Employees.EmployeeID = @EmployeeID
			
			FETCH NEXT FROM cursor_EmpID INTO 
				@EmployeeID 
		END;

	CLOSE cursor_EmpID;

	DEALLOCATE cursor_EmpID;

END
GO


